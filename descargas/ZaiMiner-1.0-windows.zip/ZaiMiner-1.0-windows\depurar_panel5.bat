@echo off
REM Si el panel v5 no abre, ejecuta esto: muestra el error en pantalla y lo guarda en panel5_error.txt
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0minero_gui5.ps1" > "%~dp0panel5_error.txt" 2>&1
type "%~dp0panel5_error.txt"
pause
