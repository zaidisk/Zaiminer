# monitor_red10.ps1 - Red y saldos (version 10: la 9 + la tabla empieza por el ALGORITMO y avisa de las monedas que puede minar cada uno)
# (v9: + Conceal, Raptoreum, Ethereum Classic, EthereumPoW y Ravencoin del panel v5)
# (v8: en zpool usa la moneda en la que te paga (DASH, DGB, LTC...) para el saldo de la wallet y su valor)
# Novedad v7: boton "API de los pools" (ventana de pools_api.ps1). Con la API configurada se ven tu saldo, lo pagado,
# tu hashrate segun el pool y los workers. Las claves API se guardan cifradas (DPAPI) en monitor\pools_api.json.
# Solo: abrir_monitor10.bat. Como pestana: los paneles v3/v4/v5 cargan solos el monitor_redN.ps1 mas alto.
# Muestra, para cada algoritmo del minero:
#   - hashrate de la red (o rentabilidad de zpool para los Argon2d)
#   - tu parte de la red con tu velocidad medida en la 3080
#   - aviso de OPORTUNIDAD cuando la red cae mucho respecto a su media (o zpool paga mucho mas que su media de 24 h)
#   - saldo de la wallet (explorador) y saldo pendiente en el pool, cuando hay API publica
# Lee las wallets y pools de minero_config.json (no lo modifica).
# Ajustes propios (tus velocidades, umbrales, clave API de Suprnova) en monitor_config.json, que se crea solo la primera vez.
# Guarda el historial de la red en monitor_historial.csv y las respuestas crudas en monitor_prueba.txt (boton "Probar fuentes").
# Se abre con abrir_monitor.bat o desde el boton "Red y saldos" del panel v2.
param([switch]$Prueba)

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]12288 } catch { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 }

$monDir      = if ($PSScriptRoot) { $PSScriptRoot } else { Split-Path -Parent $MyInvocation.MyCommand.Path }
$monRaiz     = Split-Path -Parent $monDir                 # F:\Gpow\minero
$cfgMin   = Join-Path $monRaiz 'minero_config.json'
$cfgMon   = Join-Path $monDir 'monitor_config.json'
$histFile = Join-Path $monDir 'monitor_historial.csv'
$pruebaF  = Join-Path $monDir 'monitor_prueba10.txt'
$walletsF = Join-Path $monRaiz 'wallets_y_pools.txt'

# ---------- monedas ----------
# id = clave en minero_config.json; vel = tu velocidad en H/s (editable en monitor_config.json)
$monedas = @(
    @{ id='decred';  nombre='Decred';      sim='DCR';   algo='BLAKE3'; vel=15.87e9 }
    @{ id='qhash';   nombre='Qubitcoin';   sim='QTC';   algo='QHash';         vel=2.10e9 }
    @{ id='quantus'; nombre='Quantus';     sim='QUAN';  algo='QPoW';          vel=337e6 }
    @{ id='verus';   nombre='Verus';       sim='VRSC';  algo='VerusHash 2.2'; vel=32e6 }
    @{ id='hoosat';  nombre='Hoosat';      sim='HTN';   algo='Hoohash';       vel=10.7e6 }
    @{ id='pepew';   nombre='PepePow';     sim='PEPEW'; algo='Hoohash v1.1.0';  vel=10.0e6 }
    @{ id='xelis';   nombre='Xelis';       sim='XEL';   algo='XelisHash v3';  vel=9.0e3 }
    @{ id='riecoin'; nombre='Riecoin';     sim='RIC';   algo='RiecoinPoW (primos)'; vel=0 }
    @{ id='adot';    nombre='Alterdot';    sim='ADOT';  algo='Argon2d16000';  vel=19.9e3;  zpool='argon2d16000' }
    @{ id='dyn';     nombre='Dynamic';     sim='DYN';   algo='Argon2d500';    vel=320e3;   zpool='argon2d500' }
    @{ id='a2k1000'; nombre='Argon2d1000'; sim='zpool'; algo='Argon2d1000';   vel=156e3;   zpool='argon2d1000' }
    @{ id='a2k4096'; nombre='Argon2d4096'; sim='zpool'; algo='Argon2d4096';   vel=40e3;    zpool='argon2d4096' }
    # v9: algoritmos del panel v5 (velocidades medidas en la 3080 con nuestros mineros)
    @{ id='ccx';     nombre='Conceal';     sim='CCX';   algo='CryptoNight-GPU'; vel=4847 }
    @{ id='rtm';     nombre='Raptoreum';   sim='RTM';   algo='GhostRider';    vel=2387 }
    @{ id='etc';     nombre='Ethereum Classic'; sim='ETC'; algo='Etchash';    vel=83.2e6 }
    @{ id='ethw';    nombre='EthereumPoW'; sim='ETHW';  algo='Ethash';        vel=83.2e6 }
    @{ id='rvn';     nombre='Ravencoin';   sim='RVN';   algo='KawPow';        vel=38.35e6 }
    # familia ProgPoW (progpow\pp_miner.exe), velocidades del banco en la 3080
    @{ id='evr';     nombre='Evrmore';     sim='EVR';   algo='EvrProgPow';    vel=38.4e6 }
    @{ id='firo';    nombre='Firo';        sim='FIRO';  algo='FiroPoW';       vel=36.2e6 }
    @{ id='zano';    nombre='Zano';        sim='ZANO';  algo='ProgPowZ';      vel=38.1e6 }
    @{ id='iron';    nombre='Iron Fish';   sim='IRON';  algo='FishHash';      vel=55e6 }
    @{ id='erg';     nombre='Ergo';        sim='ERG';   algo='Autolykos2';    vel=177.5e6 }
    @{ id='epic';    nombre='Epic Cash';   sim='EPIC';  algo='ProgPow';       vel=39.6e6 }
    @{ id='cfx';     nombre='Conflux';     sim='CFX';   algo='Octopus';       vel=43.6e6 }
)

# ---------- ajustes ----------
$ajustes = [ordered]@{
    minutos_refresco   = 10      # cada cuanto se actualiza solo
    umbral_red         = 0.70    # oportunidad si la red baja a menos del 70% de su mediana de 24 h
    umbral_zpool       = 1.30    # oportunidad si zpool paga ahora 30% mas que su media de 24 h
    suprnova_api_key   = ''      # opcional: tu clave API de Suprnova (Mi cuenta > Editar cuenta) para ver saldos alli
    velocidades        = [ordered]@{}
    segundos_bloque    = [ordered]@{ decred = 300; qhash = 600; verus = 60; hoosat = 0.2; pepew = 20; xelis = 5; ccx = 120; rtm = 120; etc = 13; ethw = 13; rvn = 60; evr = 60; firo = 300; zano = 120; iron = 60; erg = 120; epic = 120; cfx = 0.5 }
    # recompensa para el minero por bloque (en monedas). Decred y Xelis se calculan solos desde la red.
    recompensa_bloque  = [ordered]@{ qhash = 50; verus = 3; hoosat = 15.51; pepew = 0; etc = 2.048; ethw = 2; rvn = 1250; ccx = 0; rtm = 0; evr = 0; firo = 0; zano = 0; iron = 0; erg = 0; epic = 0; cfx = 0 }
    # identificadores de CoinGecko para el precio (si alguno sale vacio, se puede cambiar aqui)
    # monedas que se pueden minar con cada algoritmo (aviso en la tabla; se puede ampliar aqui)
    monedas_algoritmo  = [ordered]@{
        'BLAKE3'          = 'DCR (Decred), Monetarium (sin pool publico)'
        'QHash'           = 'QTC (Qubitcoin)'
        'QPoW'            = 'QUAN (Quantus)'
        'VerusHash 2.2'   = 'VRSC (Verus) y cadenas PBaaS de Verus (vARRR, vDEX, CHIPS...)'
        'Hoohash'         = 'HTN (Hoosat)'
        'Hoohash v1.1.0'  = 'PEPEW (PepePow)'
        'XelisHash v3'    = 'XEL (Xelis)'
        'RiecoinPoW (primos)' = 'RIC (Riecoin)'
        'Argon2d16000'    = 'ADOT (Alterdot); en zpool cobras en la moneda que elijas'
        'Argon2d500'      = 'DYN (Dynamic); en zpool cobras en la moneda que elijas'
        'Argon2d1000'     = 'zpool: cobras en la moneda que elijas (DASH, DGB, LTC...)'
        'Argon2d4096'     = 'UIS (Unitus); en zpool cobras en la moneda que elijas'
        'CryptoNight-GPU' = 'CCX (Conceal), RYO (Ryo)'
        'GhostRider'      = 'RTM (Raptoreum); en zpool cobras en la moneda que elijas'
        'Etchash'         = 'ETC (Ethereum Classic)'
        'Ethash'          = 'ETHW (EthereumPoW)'
        'KawPow'          = 'RVN (Ravencoin), NEOX (Neoxa), CLORE (Clore.ai), XNA (Neurai), AIPG (AI Power Grid) y otras'
        'EvrProgPow'      = 'EVR (Evrmore)'
        'FiroPoW'         = 'FIRO (Firo)'
        'ProgPowZ'        = 'ZANO (Zano)'
        'Autolykos2'      = 'ERG (Ergo)'
        'Octopus'         = 'Conflux (CFX)'
        'ProgPow'         = 'EPIC (Epic Cash; la red mezcla RandomX, ProgPoW y Cuckoo)'
        'FishHash'        = 'IRON (Iron Fish); ojo: pocos pools (Kryptex lo quito el 10/11/2026)'
    }
    precio_ids         = [ordered]@{ decred = 'decred'; qhash = 'qubitcoin-2'; verus = 'verus-coin'; hoosat = 'hoosat-network'; xelis = 'xelis'; riecoin = 'riecoin'; pepew = 'pepepow'; dgb = 'digibyte'; ccx = 'conceal'; rtm = 'raptoreum'; etc = 'ethereum-classic'; ethw = 'ethereum-pow-iou'; rvn = 'ravencoin'; evr = 'evrmore'; firo = 'zcoin'; zano = 'zano'; iron = 'iron-fish'; erg = 'ergo'; epic = 'epic-cash'; cfx = 'conflux-token' }
}
foreach ($m in $monedas) { $ajustes.velocidades[$m.id] = $m.vel }
if (Test-Path $cfgMon) {
    try {
        $j = Get-Content $cfgMon -Raw | ConvertFrom-Json
        foreach ($k in @('minutos_refresco','umbral_red','umbral_zpool','suprnova_api_key')) { if ($null -ne $j.$k) { $ajustes[$k] = $j.$k } }
        if ($j.velocidades) { foreach ($m in $monedas) { if ($null -ne $j.velocidades.($m.id)) { $ajustes.velocidades[$m.id] = [double]$j.velocidades.($m.id) } } }
        if ($j.segundos_bloque) { foreach ($m in $monedas) { if ($null -ne $j.segundos_bloque.($m.id)) { $ajustes.segundos_bloque[$m.id] = [double]$j.segundos_bloque.($m.id) } } }
        if ($j.recompensa_bloque) { foreach ($p in $j.recompensa_bloque.PSObject.Properties) { $ajustes.recompensa_bloque[$p.Name] = [double]$p.Value } }
        if ($j.monedas_algoritmo) { foreach ($p in $j.monedas_algoritmo.PSObject.Properties) { $n_ = $p.Name; if ($n_ -eq 'CNG') { continue }; $ajustes.monedas_algoritmo[$n_] = [string]$p.Value } }
        if ($j.monedas_algoritmo -and $j.monedas_algoritmo.'CNG') { $script:reescribir = $true }   # quitar la clave CNG de una prueba anterior
        if ($j.precio_ids) { foreach ($p in $j.precio_ids.PSObject.Properties) { $ajustes.precio_ids[$p.Name] = [string]$p.Value } }
    } catch { }
    try { if ($j -and (-not $j.precio_ids -or -not $j.monedas_algoritmo -or $script:reescribir -or @($monedas | Where-Object { $null -eq $j.velocidades.($_.id) }).Count -gt 0)) { ($ajustes | ConvertTo-Json -Depth 4) | Set-Content -Path $cfgMon -Encoding UTF8 } } catch { }
} else {
    try { ($ajustes | ConvertTo-Json -Depth 4) | Set-Content -Path $cfgMon -Encoding UTF8 } catch { }
}

# ---------- wallets y pools del minero ----------
$mcfg = $null
if (Test-Path $cfgMin) { try { $mcfg = Get-Content $cfgMin -Raw | ConvertFrom-Json } catch { } }
function Dato($id, $campo) { if ($mcfg -and $mcfg.$id -and $mcfg.$id.$campo) { return [string]$mcfg.$id.$campo } ; return '' }
function Host-Pool($p) { $h = $p -replace '^(stratum)+\+?(tcp|ssl)?://', '' ; return ($h -split ':')[0] }

$script:recDin = @{}     # recompensas calculadas desde la red
$script:precios = @{}    # precio USD por id de moneda (y 'dgb')

# ---------- utilidades web ----------
$script:crudo = New-Object System.Text.StringBuilder
function Anotar($txt) {
    if ($ajustes.suprnova_api_key -and $txt) { $txt = ([string]$txt).Replace([string]$ajustes.suprnova_api_key, '***') }   # no dejar la clave en monitor_prueba
    [void]$script:crudo.AppendLine($txt)
}
function Texto($c) { if ($c -is [byte[]]) { return [System.Text.Encoding]::UTF8.GetString($c) } ; return [string]$c }
function Web-Get($url) {
    $r = Invoke-WebRequest -Uri $url -UseBasicParsing -TimeoutSec 15 -Headers @{ 'User-Agent' = 'Mozilla/5.0 monitor-minero'; 'Accept' = 'application/json' }
    $t = Texto $r.Content
    Anotar ("GET  $url`r`n     " + $t.Substring(0, [Math]::Min(600, $t.Length)))
    return ($t | ConvertFrom-Json)
}
function Web-Rpc($url, $metodo, $params) {
    $obj = @{ jsonrpc = '2.0'; id = 1; method = $metodo }
    if ($null -ne $params) { $obj.params = $params }
    $cuerpo = $obj | ConvertTo-Json -Depth 5 -Compress
    $r = Invoke-WebRequest -Uri $url -Method Post -Body $cuerpo -ContentType 'application/json' -UseBasicParsing -TimeoutSec 15
    $t = Texto $r.Content
    Anotar ("POST $url $metodo`r`n     " + $t.Substring(0, [Math]::Min(600, $t.Length)))
    return ($t | ConvertFrom-Json)
}
# prueba varias fuentes; devuelve el primer valor valido (> 0) y de donde salio
function Primero([scriptblock[]]$intentos) {
    foreach ($b in $intentos) {
        try { $v = & $b ; if ($null -ne $v -and $v.valor -ne $null -and [double]$v.valor -gt 0) { return $v } }
        catch { Anotar ("     error: " + $_.Exception.Message) }
    }
    return $null
}
function Res($valor, $fuente) { return @{ valor = [double]$valor; fuente = $fuente } }
# JSON-RPC de cadenas tipo Ethereum: numeros en hexadecimal
function Hex-Num([string]$h) { if (-not $h) { return 0.0 }; $h = $h -replace '^0x', ''; $v = 0.0; foreach ($c in $h.ToCharArray()) { $v = $v * 16 + [Convert]::ToInt32([string]$c, 16) }; return $v }
# 2Miners (open-ethereum-pool): /api/stats -> nodes[0].networkhashps ; /api/accounts/WALLET -> stats.balance
function DosMiners-Red($sub) { $j = Web-Get "https://$sub.2miners.com/api/stats"; $n = @($j.nodes)[0]; $h = [double]$n.networkhashps; if (-not $h -and $n.difficulty) { $h = [double]$n.difficulty / [double]$ajustes.segundos_bloque[$sub] }; return (Res $h "2miners $sub") }
function DosMiners-Saldo($sub, $w, $factor) { $j = Web-Get "https://$sub.2miners.com/api/accounts/$w"; return (Res ([double]$j.stats.balance * $factor + 1e-12) "2miners $sub") }

# Suprnova (MPOS): pagina publica sin clave; network_hashrate en H/s
function Suprnova-Red($sub) { $j = Web-Get "https://$sub.suprnova.cc/index.php?page=api&action=public"; return (Res $j.network_hashrate "suprnova $sub") }
function Suprnova-Saldo($sub) {
    if (-not $ajustes.suprnova_api_key) { return $null }
    $j = Web-Get "https://$sub.suprnova.cc/index.php?page=api&action=getuserbalance&api_key=$($ajustes.suprnova_api_key)"
    $d = $j.getuserbalance.data
    return (Res ([double]$d.confirmed + [double]$d.unconfirmed) "suprnova $sub")
}
# Pools tipo MiningCore (api/pools)
function MiningCore-Pool($dominio, $sim) {
    $j = Web-Get "https://$dominio/api/pools"
    foreach ($p in $j.pools) { if ($p.coin.symbol -eq $sim -or $p.coin.type -eq $sim) { return $p } }
    return $null
}
function MiningCore-Red($dominio, $sim) { $p = MiningCore-Pool $dominio $sim ; if ($p) { return (Res $p.networkStats.networkHashrate "pool $dominio") } ; return $null }
function MiningCore-Saldo($dominio, $sim, $wallet) {
    $p = MiningCore-Pool $dominio $sim ; if (-not $p) { return $null }
    $j = Web-Get "https://$dominio/api/pools/$($p.id)/miners/$wallet"
    return (Res ([double]$j.pendingBalance + 0.000000001) "pool $dominio")
}

# Pools tipo YIIMP (api/currencies, api/wallet)
function Yiimp-Red($dominio, $sim) { $j = Web-Get "https://$dominio/api/currencies"; $c = $j.$sim; if ($c) { return (Res $c.network_hashrate "pool $dominio") } ; return $null }
function Yiimp-Saldo($dominio, $wallet) { $j = Web-Get "https://$dominio/api/wallet?address=$wallet"; return (Res ([double]$j.unpaid + 1e-12) "pool $dominio") }

# ---------- API de los pools (pools_api.ps1) ----------
$apiOk = $false
try { . (Join-Path $monDir 'pools_api.ps1'); $apiOk = $true } catch { }

# ---------- precios ----------
# monedas en las que paga zpool -> id de CoinGecko (para el precio del saldo)
$idsPago = [ordered]@{ DASH = 'dash'; DGB = 'digibyte'; LTC = 'litecoin'; BTC = 'bitcoin'; DOGE = 'dogecoin'; RVN = 'ravencoin'; KMD = 'komodo'; BCH = 'bitcoin-cash'; ZEC = 'zcash'; XMR = 'monero'; ETC = 'ethereum-classic'; FLUX = 'zelcash' }
# zpool: una consulta por wallet y actualizacion (las 4 filas Argon2d comparten wallet; zpool limita las consultas)
$script:zpoolCache = @{}
function Zpool-Wallet($w) {
    if (-not $w) { return $null }
    if ($script:zpoolCache.ContainsKey($w)) { return $script:zpoolCache[$w] }
    $j = $null
    try { $j = Web-Get "https://zpool.ca/api/wallet?address=$w" } catch { Anotar ('     error zpool wallet: ' + $_.Exception.Message) }
    $script:zpoolCache[$w] = $j
    return $j
}
# moneda en la que te paga zpool: la que dice zpool; si no responde, la del password (c=DASH); si no, DGB
function Moneda-Pago($m, $w) {
    $j = Zpool-Wallet $w
    if ($j -and $j.currency) { return ([string]$j.currency).ToUpper() }
    $pw = Dato $m.id 'password'
    if ($pw -match 'c=([A-Za-z0-9]+)') { return $Matches[1].ToUpper() }
    return 'DGB'
}
function Cargar-Precios {
    $script:precios = @{}
    $ids = @(@($ajustes.precio_ids.Values) + @($idsPago.Values) | Where-Object { $_ } | Select-Object -Unique) -join ','
    try {
        $j = Web-Get "https://api.coingecko.com/api/v3/simple/price?ids=$ids&vs_currencies=usd"
        foreach ($k in @($ajustes.precio_ids.Keys)) { $cg = $ajustes.precio_ids[$k]; if ($cg -and $j.$cg -and $j.$cg.usd) { $script:precios[$k] = [double]$j.$cg.usd } }
        foreach ($k in @($idsPago.Keys)) { $cg = $idsPago[$k]; if ($j.$cg -and $j.$cg.usd) { $script:precios['pago_' + $k] = [double]$j.$cg.usd } }
    } catch { Anotar ('     error precios: ' + $_.Exception.Message) }
    if (-not $script:precios.ContainsKey('pepew')) {
        try {
            $j = Web-Get 'https://light.pepepow.net/api/price'
            if ($j -is [array]) { $j = $j[0] }
            if ($j.ticker) { $j = $j.ticker } elseif ($j.data) { $j = $j.data }
            foreach ($k in @('last_price','last','price')) { if ($j.$k) { $script:precios['pepew'] = [double]$j.$k; break } }
        } catch { Anotar ('     error precio pepew: ' + $_.Exception.Message) }
    }
}
function Fmt-USD([double]$x) { if ($x -le 0) { return '-' } ; if ($x -ge 100) { return ('{0:N0} $' -f $x) } ; if ($x -ge 1) { return ('{0:N2} $' -f $x) } ; if ($x -ge 0.01) { return ('{0:N3} $' -f $x) } ; return ('{0:N6} $' -f $x) }

# ---------- red por moneda ----------
function Red-De($m) {
    switch ($m.id) {
        'decred'  { return Primero @(
                        { $j = Web-Get 'https://dcrdata.decred.org/api/block/best'; $script:recDin['decred'] = 31.19582664 * [Math]::Pow(100.0/101.0, [Math]::Floor([double]$j.height / 6144)) * 0.01; Res ([double]$j.diff * 4294967296 / 300) 'dcrdata' },
                        { Suprnova-Red 'dcr' }) }
        'qhash'   { return Primero @({ Suprnova-Red 'qtc' }) }
        'quantus' { return $null }   # quantus.suprnova.cc no tiene API publica
        'verus'   { return Primero @(
                        { $j = Web-Rpc 'https://api.verus.services' 'getmininginfo' @(); Res $j.result.networkhashps 'api.verus.services' }) }
        'hoosat'  { return Primero @(
                        { $j = Web-Get 'https://api.network.hoosat.fi/info/hashrate?stringOnly=false'; Res ([double]$j.hashrate * 1e12) 'api.network.hoosat.fi' },
                        { $j = Web-Get 'https://proxy.hoosat.net/api/v1/info/hashrate'; Res ([double]$j.hashrate * 1e12) 'proxy.hoosat.net' },
                        { $null }) }
        'pepew'   { return Primero @(
                        { $j = Web-Get 'https://pool.pepepow.net/api/network/summary'
                          $h = $j.networkHashrate; if (-not $h) { $h = $j.network_hashrate }; if (-not $h) { $h = $j.hashrate }
                          # recompensa (pool.pepepow.net app.js): 16000 desde 2189200, -500 cada 129600 bloques desde 2318801, minimo 5000;
                          # al minero le toca 95% (sin dev fee) x 65% (resto masternodes). Bloque cada 20 s.
                          $alt = $j.height; if (-not $alt) { $alt = $j.blockHeight }; if (-not $alt) { $alt = $j.blocks }
                          $ajustes.segundos_bloque['pepew'] = 20
                          if ($alt -and [double]$alt -ge 2189200) {
                              $red_ = if ([double]$alt -lt 2318801) { 0 } else { [Math]::Floor(([double]$alt - 2318801) / 129600) + 1 }
                              $script:recDin['pepew'] = [Math]::Max(5000, 16000 - $red_ * 500) * 0.95 * 0.65
                          }
                          Res $h 'pool.pepepow.net' }) }
        'xelis'   { return Primero @(
                        { $j = Web-Rpc 'https://node.xelis.io/json_rpc' 'get_info' $null; if ($j.result.block_time_target) { $ajustes.segundos_bloque['xelis'] = [double]$j.result.block_time_target / 1000 }; if ($j.result.miner_reward) { $script:recDin['xelis'] = [double]$j.result.miner_reward / 1e8 }; Res ([double]$j.result.difficulty / ([double]$j.result.block_time_target / 1000)) 'node.xelis.io' },
                        { Suprnova-Red 'xel' }) }
        'etc'     { return Primero @(
                        { DosMiners-Red 'etc' },
                        { $j = Web-Rpc 'https://etc.rivet.link' 'eth_getBlockByNumber' @('latest', $false); Res ((Hex-Num $j.result.difficulty) / 13) 'etc.rivet.link' }) }
        'ethw'    { return Primero @(
                        { DosMiners-Red 'ethw' },
                        { $j = Web-Rpc 'https://mainnet.ethereumpow.org' 'eth_getBlockByNumber' @('latest', $false); Res ((Hex-Num $j.result.difficulty) / 13) 'mainnet.ethereumpow.org' }) }
        'rvn'     { return Primero @(
                        { DosMiners-Red 'rvn' },
                        { $j = Web-Get 'https://chainz.cryptoid.info/rvn/api.dws?q=getdifficulty'; Res ([double]$j * 4294967296 / 60) 'cryptoid RVN' }) }
        'evr'     { return Primero @(
                        { $j = Web-Get 'https://evr.cryptoscope.io/api/getnetworkhashps/'; Res $j 'evr.cryptoscope.io' },
                        { $j = Web-Get 'https://evr.cryptoscope.io/api/getdifficulty/'; Res ([double]$j * 4294967296 / 60) 'evr.cryptoscope.io (dificultad)' }) }
        'firo'    { return Primero @(
                        { DosMiners-Red 'firo' },
                        { $j = Web-Get 'https://chainz.cryptoid.info/firo/api.dws?q=getdifficulty'; Res ([double]$j * 4294967296 / 300) 'cryptoid FIRO' }) }
        # Epic Cash: bloque cada 60 s repartido entre 3 algoritmos; ~120 s por bloque ProgPoW (aprox., editable). Saldos privados (MimbleWimble).
        'epic'    { return Primero @(
                        { $j = Web-Get 'https://explorer.epiccash.com/api?q=getdifficulty-progpow'; Res ([double]$j / [double]$ajustes.segundos_bloque['epic']) 'explorer.epiccash.com' }) }
        'erg'     { return Primero @(
                        { $j = Web-Get 'https://api.ergoplatform.com/api/v1/info'; Res $j.hashRate 'api.ergoplatform.com' },
                        { $j = Web-Get 'https://api.ergoplatform.com/api/v1/networkState'; Res ([double]$j.difficulty / 120) 'api.ergoplatform.com (dificultad)' },
                        { DosMiners-Red 'erg' }) }
        # Conflux: bloque cada 0,5 s (aprox., editable); hashrate = dificultad / segundos_bloque
        'cfx'     { return Primero @(
                        { $j = Web-Rpc 'https://main.confluxrpc.com' 'cfx_getBlockByEpochNumber' @('latest_mined', $false); Res ((Hex-Num $j.result.difficulty) / [double]$ajustes.segundos_bloque['cfx']) 'main.confluxrpc.com' },
                        { DosMiners-Red 'cfx' }) }
        'iron'    { return Primero @(
                        { $j = Web-Get 'https://api.ironfish.network/blocks/head'; $h = [double]$j.hashrate; if (-not $h) { $h = [double]$j.difficulty / 60 }; Res $h 'api.ironfish.network' }) }
        'zano'    { return Primero @(
                        { $j = Web-Rpc 'https://explorer.zano.org/json_rpc' 'getinfo' @{ flags = 1048575 }; Res ([double]$j.result.pow_difficulty / 120) 'explorer.zano.org' }) }
        'rtm'     { return Primero @(
                        { $j = Web-Get 'https://explorer.raptoreum.com/api/getnetworkhashps'; Res $j 'explorer.raptoreum.com' }) }
        'ccx'     { return Primero @(
                        { $j = Web-Get 'https://explorer.conceal.network/daemon/getinfo'; Res ([double]$j.difficulty / 120) 'explorer.conceal.network' },
                        { $j = Web-Get 'http://node.conceal.network:16000/getinfo'; Res ([double]$j.difficulty / 120) 'node.conceal.network' }) }
        default   { return $null }
    }
}

# ---------- saldos ----------
function Saldo-Wallet($m, $w) {
    if (-not $w) { return $null }
    switch ($m.id) {
        'decred'  { return Primero @({ $j = Web-Get "https://dcrdata.decred.org/api/address/$w/totals"; Res ([double]$j.dcr_unspent + 1e-12) 'dcrdata' }) }
        'verus'   { return Primero @({ $j = Web-Rpc 'https://api.verus.services' 'getaddressbalance' @(@{ addresses = @($w) }); Res ([double]$j.result.balance / 1e8 + 1e-12) 'api.verus.services' }) }
        'hoosat'  { return Primero @(
                        { $j = Web-Get "https://api.network.hoosat.fi/addresses/$w/balance"; Res ([double]$j.balance / 1e8 + 1e-12) 'api.network.hoosat.fi' },
                        { $j = Web-Get "https://proxy.hoosat.net/api/v1/addresses/$w/balance"; Res ([double]$j.balance / 1e8 + 1e-12) 'proxy.hoosat.net' }) }
        'riecoin' { return Primero @({ $j = Web-Get "https://chainz.cryptoid.info/ric/api.dws?q=getbalance&a=$w"; Res ([double]$j + 1e-12) 'cryptoid' }) }
        'etc'     { return Primero @({ $j = Web-Rpc 'https://etc.rivet.link' 'eth_getBalance' @($w, 'latest'); Res ((Hex-Num $j.result) / 1e18 + 1e-12) 'etc.rivet.link' }) }
        'ethw'    { return Primero @({ $j = Web-Rpc 'https://mainnet.ethereumpow.org' 'eth_getBalance' @($w, 'latest'); Res ((Hex-Num $j.result) / 1e18 + 1e-12) 'mainnet.ethereumpow.org' }) }
        'rvn'     { return Primero @({ $j = Web-Get "https://chainz.cryptoid.info/rvn/api.dws?q=getbalance&a=$w"; Res ([double]$j + 1e-12) 'cryptoid RVN' }) }
        'erg'     { return Primero @({ $j = Web-Get "https://api.ergoplatform.com/api/v1/addresses/$w/balance/confirmed"; Res ([double]$j.nanoErgs / 1e9 + 1e-12) 'api.ergoplatform.com' }) }
        'cfx'     { return Primero @({ $j = Web-Rpc 'https://main.confluxrpc.com' 'cfx_getBalance' @($w, 'latest_state'); Res ((Hex-Num $j.result) / 1e18 + 1e-12) 'main.confluxrpc.com' }) }
        'firo'    { return Primero @({ $j = Web-Get "https://chainz.cryptoid.info/firo/api.dws?q=getbalance&a=$w"; Res ([double]$j + 1e-12) 'cryptoid FIRO' }) }
        'rtm'     { return Primero @({ $j = Web-Get "https://explorer.raptoreum.com/ext/getbalance/$w"; Res ([double]$j + 1e-12) 'explorer.raptoreum.com' }) }
        'pepew'   { return Primero @({ $j = Web-Get "https://light.pepepow.net/api/wallet/address/$w"
                                           Res ([double]$j.balance.confirmed_pepew + [double]$j.balance.unconfirmed_pepew + 1e-12) 'light.pepepow.net' }) }
        { $_ -in @('adot','dyn','a2k1000','a2k4096') } {
                    $sp_ = (Moneda-Pago $m $w).ToLower()
                    return Primero @({ $j = Web-Get "https://chainz.cryptoid.info/$sp_/api.dws?q=getbalance&a=$w"; Res ([double]$j + 1e-12) ('cryptoid ' + $sp_.ToUpper()) }) }
        default   { return $null }   # Xelis: los saldos estan cifrados en la cadena; solo se ve el del pool
    }
}
function Saldo-Pool($m, $w, $pool) {
    $h = Host-Pool $pool
    switch ($m.id) {
        'decred'  { return Primero @({ Suprnova-Saldo 'dcr' }) }
        'qhash'   { return Primero @({ Suprnova-Saldo 'qtc' }) }
        'quantus' { return Primero @({ Suprnova-Saldo 'quantus' }) }
        'verus'   { if (-not $w) { return $null }; return Primero @({ $j = Web-Get "https://luckpool.net/verus/miner/$w"; Res ([double]$j.balance + 1e-12) 'luckpool' }) }
        'hoosat'  { return $null }   # nushypool: sin API publica (ver su web)
        'rtm'     { if (-not $w -or $h -notlike '*zpool.ca') { return $null }; $j = Zpool-Wallet $w; if (-not $j) { return $null }
                    return (Res ([double]$j.unpaid + 1e-12) ("zpool (" + $j.currency + ")")) }   # flockpool: ver su web
        # 2Miners: saldo en Shannon (1e-9) en ETC/ETHW; en RVN en 1e-8 (si sale raro, configurar con la ventana API de los pools)
        { $_ -in @('etc','ethw','rvn') } {
                    if (-not $w -or $h -notlike '*2miners.com') { return $null }
                    $f_ = if ($m.id -eq 'rvn') { 1e-8 } else { 1e-9 }
                    return Primero @({ DosMiners-Saldo $m.id $w $f_ }) }
        'xelis'   { if ($h -like '*suprnova*') { return Primero @({ Suprnova-Saldo 'xel' }) }; if (-not $w) { return $null }; return $null }   # nushypool: sin API publica
        'pepew'   { if (-not $w) { return $null }
                    return Primero @({ $j = Web-Get "https://pool.pepepow.net/api/miner/$w"; Res ([double]$j.totalPaidManual + 1e-12) 'pool.pepepow.net (pagado)' }) }
        { $_ -in @('adot','dyn','a2k1000','a2k4096') } {
                    if (-not $w) { return $null }; $j = Zpool-Wallet $w; if (-not $j) { return $null }
                    return (Res ([double]$j.unpaid + 1e-12) ("zpool (" + $j.currency + ")")) }
        default   { return $null }
    }
}

# ---------- historial ----------
$script:hist = @{}
if (Test-Path $histFile) {
    foreach ($l in Get-Content $histFile) {
        $p = $l -split ';' ; if ($p.Count -lt 3) { continue }
        try { $t = [datetime]::Parse($p[0]) } catch { continue }
        if (-not $script:hist.ContainsKey($p[1])) { $script:hist[$p[1]] = New-Object System.Collections.Generic.List[object] }
        $script:hist[$p[1]].Add(@{ t = $t; v = [double]$p[2] })
    }
}
function Guardar-Hist($id, $v) {
    $ahora = Get-Date
    if (-not $script:hist.ContainsKey($id)) { $script:hist[$id] = New-Object System.Collections.Generic.List[object] }
    $script:hist[$id].Add(@{ t = $ahora; v = $v })
    try { Add-Content -Path $histFile -Value ("{0};{1};{2}" -f $ahora.ToString('s'), $id, $v) } catch { }
}
function Mediana24($id) {
    if (-not $script:hist.ContainsKey($id)) { return $null }
    $desde = (Get-Date).AddHours(-24)
    $vals = @($script:hist[$id] | Where-Object { $_.t -ge $desde } | ForEach-Object { $_.v } | Sort-Object)
    if ($vals.Count -lt 6) { return $null }     # hacen falta al menos 6 medidas (1 hora) para comparar
    return $vals[[int][Math]::Floor($vals.Count / 2)]
}

# ---------- formato ----------
function Fmt-H([double]$h) {
    if ($h -le 0) { return '-' }
    $u = @('H/s','kH/s','MH/s','GH/s','TH/s','PH/s','EH/s'); $i = 0
    while ($h -ge 1000 -and $i -lt 6) { $h /= 1000; $i++ }
    return ('{0:N2} {1}' -f $h, $u[$i])
}
function Fmt-T([double]$s) {
    if ($s -le 0) { return '-' }
    if ($s -lt 120) { return ('{0:N0} s' -f $s) }
    if ($s -lt 7200) { return ('{0:N0} min' -f ($s / 60)) }
    if ($s -lt 172800) { return ('{0:N1} h' -f ($s / 3600)) }
    if ($s -lt 63072000) { return ('{0:N0} dias' -f ($s / 86400)) }
    return ('{0:N0} anos' -f ($s / 31557600))
}
function Fmt-N([double]$x) { if ($x -ge 1000) { return ('{0:N0}' -f $x) } ; if ($x -ge 1) { return ('{0:N3}' -f $x) } ; return ('{0:N6}' -f $x) }

# ---------- ventana (o pestana) ----------
$cFondo = [System.Drawing.Color]::FromArgb(245, 246, 248)
$cVerdeClaro = [System.Drawing.Color]::FromArgb(209, 231, 221)
$cGris = [System.Drawing.Color]::FromArgb(108, 117, 125)

$monSolo = -not $monContenedor
if ($monSolo) {
    $monForm = New-Object System.Windows.Forms.Form
    $monForm.Text = 'Red y saldos - monitor del minero'
    $monForm.ClientSize = New-Object System.Drawing.Size(1300, 560)
    $monForm.StartPosition = 'CenterScreen'
    $monForm.Font = New-Object System.Drawing.Font('Segoe UI', 9.5)
} else {
    $monForm = $monContenedor
}
$monForm.BackColor = $cFondo

$grid = New-Object System.Windows.Forms.DataGridView
$grid.Dock = 'Fill'
$grid.ReadOnly = $true; $grid.AllowUserToAddRows = $false; $grid.RowHeadersVisible = $false
$grid.SelectionMode = 'FullRowSelect'; $grid.BackgroundColor = [System.Drawing.Color]::White; $grid.BorderStyle = 'None'
$grid.AutoSizeColumnsMode = 'AllCells'; $grid.ScrollBars = 'Both'
foreach ($c in @('Algoritmo','Moneda consultada','Monedas que puede minar','Red ahora','Mediana 24 h','Tu velocidad','Tu parte','Bloque en 24 h','Tiempo medio por bloque','Precio','Bloque vale','USD/dia esperado','Estado','Saldo wallet','Saldo en pool','Pagado (pool)','Tu hashrate en pool','Workers','Valor saldos','Fuentes')) { [void]$grid.Columns.Add($c, $c) }

$monArriba = New-Object System.Windows.Forms.Panel
$monArriba.Dock = 'Top'; $monArriba.Height = 52; $monArriba.BackColor = $cFondo
$btnAct = New-Object System.Windows.Forms.Button
$btnAct.Text = 'Actualizar ahora'; $btnAct.Location = New-Object System.Drawing.Point(12, 12); $btnAct.Size = New-Object System.Drawing.Size(150, 30)
$monArriba.Controls.Add($btnAct)
$btnProb = New-Object System.Windows.Forms.Button
$btnProb.Text = 'Probar fuentes'; $btnProb.Location = New-Object System.Drawing.Point(172, 12); $btnProb.Size = New-Object System.Drawing.Size(130, 30)
$monArriba.Controls.Add($btnProb)
$btnWal = New-Object System.Windows.Forms.Button
$btnWal.Text = 'Exportar wallets y pools'; $btnWal.Location = New-Object System.Drawing.Point(312, 12); $btnWal.Size = New-Object System.Drawing.Size(190, 30)
$monArriba.Controls.Add($btnWal)
$btnApi = New-Object System.Windows.Forms.Button
$btnApi.Text = 'API de los pools'; $btnApi.Location = New-Object System.Drawing.Point(512, 12); $btnApi.Size = New-Object System.Drawing.Size(150, 30)
$btnApi.Enabled = $apiOk
$monArriba.Controls.Add($btnApi)
$btnAlg = New-Object System.Windows.Forms.Button
$btnAlg.Text = 'Monedas por algoritmo'; $btnAlg.Location = New-Object System.Drawing.Point(672, 12); $btnAlg.Size = New-Object System.Drawing.Size(180, 30)
$monArriba.Controls.Add($btnAlg)
$monLbl = New-Object System.Windows.Forms.Label
$monLbl.Location = New-Object System.Drawing.Point(866, 18); $monLbl.Size = New-Object System.Drawing.Size(700, 22); $monLbl.ForeColor = $cGris
$monLbl.Text = 'Cargando...'
$monArriba.Controls.Add($monLbl)

$nota = New-Object System.Windows.Forms.Label
$nota.Dock = 'Bottom'; $nota.Height = 68; $nota.ForeColor = $cGris; $nota.Padding = New-Object System.Windows.Forms.Padding(8, 4, 8, 4)
$nota.Text = "Tu parte = tu velocidad / red. Bloque en 24 h = probabilidad de encontrar tu un bloque en 24 h minando solo (en pool cobras por shares). USD/dia esperado = tu parte x bloques al dia x recompensa x precio (antes de luz y comisiones). OPORTUNIDAD: la red esta por debajo del $([int]($ajustes.umbral_red*100))% de su mediana de 24 h (o zpool paga $([int](($ajustes.umbral_zpool-1)*100))% mas que su media). " +
             "La comparacion necesita al menos 1 hora de historial. Ajustes en monitor\monitor_config.json." +
             " Cada fila es un ALGORITMO: 'Moneda consultada' es la moneda cuya red se mide y 'Monedas que puede minar' avisa de las demas (boton 'Monedas por algoritmo')."

$monForm.Controls.Add($grid)
$monForm.Controls.Add($monArriba)
$monForm.Controls.Add($nota)
$grid.BringToFront()     # el grid ocupa lo que dejan la barra de arriba y la nota de abajo

$icono = New-Object System.Windows.Forms.NotifyIcon
$icono.Icon = [System.Drawing.SystemIcons]::Information; $icono.Visible = $true; $icono.Text = 'Monitor del minero'

# ---------- exportar wallets y pools ----------
function Exportar-Wallets {
    $sb = New-Object System.Text.StringBuilder
    [void]$sb.AppendLine('WALLETS Y POOLS DEL MINERO  (generado ' + (Get-Date).ToString('yyyy-MM-dd HH:mm') + ')')
    [void]$sb.AppendLine('Sacado de minero_config.json. Contiene tus direcciones: no lo compartas.')
    [void]$sb.AppendLine('')
    foreach ($m in $monedas) {
        $pool = Dato $m.id 'pool'; $w = Dato $m.id 'wallet'; $wk = Dato $m.id 'worker'; $pw = Dato $m.id 'password'
        [void]$sb.AppendLine(('{0} ({1}, {2})' -f $m.nombre, $m.sim, $m.algo))
        [void]$sb.AppendLine('   Pool:     ' + $(if ($pool) { $pool } else { '(sin configurar)' }))
        [void]$sb.AppendLine('   Wallet:   ' + $(if ($w) { $w } else { '(sin configurar)' }))
        [void]$sb.AppendLine('   Worker:   ' + $wk + '    Password: ' + $pw)
        if ($pool -match '^stratum.*stratum') { [void]$sb.AppendLine('   OJO: el pool tiene "stratum" repetido; deberia empezar por stratum+tcp:// una sola vez.') }
        [void]$sb.AppendLine('')
    }
    Set-Content -Path $walletsF -Value $sb.ToString() -Encoding UTF8
    return $walletsF
}

# ---------- actualizar ----------
$script:avisados = @{}
function Actualizar([bool]$prueba) {
    $btnAct.Enabled = $false; $btnProb.Enabled = $false; $btnApi.Enabled = $false
    [void]$script:crudo.Clear()
    $apiLista = @(); if ($apiOk) { try { $apiTodas = Api-Cargar; $apiLista = @($apiTodas | Where-Object { $_.activo }) } catch { } }
    $apiUsadas = @{}
    # releer wallets y pools por si se cambiaron en el panel
    if (Test-Path $cfgMin) { try { $script:mcfg = Get-Content $cfgMin -Raw | ConvertFrom-Json } catch { } }
    $grid.Rows.Clear()
    $script:zpoolCache = @{}
    $zp = $null
    try { $zp = Web-Get 'https://zpool.ca/api/status' } catch { Anotar ('     error zpool: ' + $_.Exception.Message) }
    $opor = @()
    Cargar-Precios
    foreach ($m in $monedas) {
        $monLbl.Text = 'Consultando ' + $m.nombre + '...'; [System.Windows.Forms.Application]::DoEvents()
        Anotar ''; Anotar ('### ' + $m.nombre)
        $w = Dato $m.id 'wallet'; $pool = Dato $m.id 'pool'
        $vel = [double]$ajustes.velocidades[$m.id]
        $redTxt = '-'; $medTxt = '-'; $parte = '-'; $p24 = '-'; $tBloque = '-'; $vBloque = '-'; $usdDia = '-';
        $simPago = if ($m.zpool) { Moneda-Pago $m $w } else { $m.sim }
        $idp = if ($m.zpool) { 'pago_' + $simPago } else { $m.id }
        $precio = 0.0; if ($script:precios.ContainsKey($idp)) { $precio = $script:precios[$idp] }; $estado = ''; $fuentes = @(); $oportunidad = $false
        if ($m.zpool) {
            $a = $null; if ($zp) { $a = $zp.($m.zpool) }
            if ($a) {
                $act = [double]$a.estimate_current; $med = [double]$a.estimate_last24h
                $redTxt = 'pool ' + (Fmt-H ([double]$a.hashrate))
                if ($med -gt 0) {
                    $r = $act / $med
                    $estado = ('paga {0:N0}% de su media 24 h' -f ($r * 100))
                    if ($r -ge $ajustes.umbral_zpool) { $oportunidad = $true }
                }
                $fuentes += 'zpool'
            } else { $estado = 'zpool sin datos' }
        } else {
            $red = Red-De $m
            if ($red) {
                $redTxt = Fmt-H $red.valor; $fuentes += $red.fuente
                $med = Mediana24 $m.id
                Guardar-Hist $m.id $red.valor
                if ($med) {
                    $medTxt = Fmt-H $med
                    $r = $red.valor / $med
                    $estado = ('red al {0:N0}% de su mediana' -f ($r * 100))
                    if ($r -le $ajustes.umbral_red) { $oportunidad = $true }
                } else { $estado = 'juntando historial' }
                if ($vel -gt 0) {
                    $fr = $vel / ($red.valor + $vel)
                    $parte = ('{0:N3} %' -f (100 * $fr))
                    $T = [double]$ajustes.segundos_bloque[$m.id]
                    if ($T -gt 0) {
                        # Poisson: bloques tuyos esperados en 24 h = parte x bloques al dia
                        $p = 1 - [Math]::Exp(-$fr * 86400 / $T)
                        $p24 = if ($p -ge 0.9995) { '~100 %' } elseif ($p -ge 0.001) { '{0:N1} %' -f (100 * $p) } else { '{0:N4} %' -f (100 * $p) }
                        $tBloque = Fmt-T ($T / $fr)
                        $rec = 0.0
                        if ($script:recDin.ContainsKey($m.id)) { $rec = $script:recDin[$m.id] } elseif ($ajustes.recompensa_bloque.Contains($m.id)) { $rec = [double]$ajustes.recompensa_bloque[$m.id] }
                        if ($rec -gt 0 -and $precio -gt 0) {
                            $vBloque = Fmt-USD ($rec * $precio)
                            $usdDia = Fmt-USD ($fr * 86400 / $T * $rec * $precio)
                        }
                    }
                }
            } elseif ($m.id -eq 'riecoin') { $estado = 'sin hashrate comparable (primos)' }
            else { $estado = 'sin datos de red' }
        }
        if ($oportunidad) { $estado = 'OPORTUNIDAD: ' + $estado; $opor += $m.nombre }
        $sw = Saldo-Wallet $m $w
        # API configurada para esta moneda (ventana "API de los pools"); si no hay, las fuentes de siempre
        $ar = $null; $apiErr = ''
        foreach ($e in $apiLista) { if ($e.moneda -eq $m.id) { $apiUsadas[$e.nombre] = $true; $ar = Api-Consultar $e; Anotar ('### API ' + $e.nombre); Anotar $ar.crudo; if ($ar.error) { $apiErr = $ar.error }; $fuentes += ('API ' + $e.host); break } }
        $sp = $null
        if ($ar -and $null -ne $ar.saldo) { $sp = Res ($ar.saldo + 1e-12) ('API ' + $e.host) }
        if (-not $sp) { $sp = Saldo-Pool $m $w $pool }
        $swTxt = if ($sw) { (Fmt-N ($sw.valor - 1e-12)) + ' ' + $simPago } elseif (-not $w) { 'sin wallet' } elseif ($m.id -eq 'xelis') { 'cifrado (ver pool)' } else { '?' }
        $pagTxt = if ($ar -and $null -ne $ar.pagado) { Fmt-N $ar.pagado } else { '-' }
        $hpTxt  = if ($ar -and $null -ne $ar.hashrate) { Fmt-H $ar.hashrate } elseif ($apiErr) { 'API: ' + $apiErr.Substring(0, [Math]::Min(45, $apiErr.Length)) } else { '-' }
        $wkTxt  = if ($ar -and $null -ne $ar.workers) { [string]$ar.workers } else { '-' }
        $spTxt = if ($sp) { (Fmt-N ($sp.valor - 1e-12)) } elseif ($m.id -in @('decred','qhash','quantus') -and -not $ajustes.suprnova_api_key) { 'falta clave API' } elseif ($pool -like '*nushypool*') { 'ver web del pool' } else { '?' }
        if ($sw) { $fuentes += $sw.fuente } ; if ($sp) { $fuentes += $sp.fuente }
        $tot = 0.0; if ($sw) { $tot += $sw.valor } ; if ($sp) { $tot += $sp.valor }
        $valTxt = if ($precio -gt 0 -and $tot -gt 1e-9) { Fmt-USD ($tot * $precio) } elseif ($precio -le 0) { 'sin precio' } else { '-' }
        $i = $grid.Rows.Add(@($m.algo, ($m.nombre + ' (' + $m.sim + ')'), (Monedas-De $m.algo), $redTxt, $medTxt, $(if ($vel -gt 0) { Fmt-H $vel } else { '-' }), $parte, $p24, $tBloque, $(if ($precio -gt 0) { Fmt-USD $precio } else { '?' }), $vBloque, $usdDia, $estado, $swTxt, $spTxt, $pagTxt, $hpTxt, $wkTxt, $valTxt, (($fuentes | Select-Object -Unique) -join ', ')))
        if ($oportunidad) { $grid.Rows[$i].DefaultCellStyle.BackColor = $cVerdeClaro; $grid.Rows[$i].DefaultCellStyle.Font = New-Object System.Drawing.Font('Segoe UI', 9.5, [System.Drawing.FontStyle]::Bold) }
        [System.Windows.Forms.Application]::DoEvents()
    }
    # pools con API configurada para algo que no esta en la lista de monedas (p.ej. algoritmos nuevos)
    foreach ($e in $apiLista) {
        if ($apiUsadas.ContainsKey($e.nombre)) { continue }
        $enLista = $false; foreach ($m in $monedas) { if ($m.id -eq $e.moneda) { $enLista = $true } }
        if ($enLista) { continue }
        $monLbl.Text = 'Consultando ' + $e.nombre + '...'; [System.Windows.Forms.Application]::DoEvents()
        $ar = Api-Consultar $e; Anotar ('### API ' + $e.nombre); Anotar $ar.crudo
        [void]$grid.Rows.Add(@($e.moneda, $e.nombre, (Monedas-De $e.moneda), '-', '-', '-', '-', '-', '-', '-', '-', '-', $(if ($ar.error) { 'API: ' + $ar.error } else { 'solo datos del pool' }), '-',
            $(if ($null -ne $ar.saldo) { Fmt-N $ar.saldo } else { '-' }), $(if ($null -ne $ar.pagado) { Fmt-N $ar.pagado } else { '-' }),
            $(if ($null -ne $ar.hashrate) { Fmt-H $ar.hashrate } else { '-' }), $(if ($null -ne $ar.workers) { [string]$ar.workers } else { '-' }), '-', ('API ' + $e.host)))
    }
    $monLbl.Text = 'Actualizado ' + (Get-Date).ToString('HH:mm') + '. Proxima en ' + $ajustes.minutos_refresco + ' min.'
    # aviso: solo una vez por moneda cada 3 horas
    $nuevas = @()
    foreach ($n in $opor) {
        if (-not $script:avisados.ContainsKey($n) -or ((Get-Date) - $script:avisados[$n]).TotalHours -ge 3) { $nuevas += $n; $script:avisados[$n] = Get-Date }
    }
    if ($nuevas.Count -gt 0) {
        [System.Media.SystemSounds]::Exclamation.Play()
        $icono.ShowBalloonTip(15000, 'Oportunidad de minado', ('Buen momento para: ' + ($nuevas -join ', ')), [System.Windows.Forms.ToolTipIcon]::Info)
    }
    if ($prueba) {
        Set-Content -Path $pruebaF -Value $script:crudo.ToString() -Encoding UTF8
        $monLbl.Text = 'Respuestas guardadas en monitor\monitor_prueba7.txt (las claves API salen tapadas con ***).'
    }
    $btnAct.Enabled = $true; $btnProb.Enabled = $true; $btnApi.Enabled = $apiOk
}

$btnAct.Add_Click({ Actualizar $false })
$btnProb.Add_Click({ Actualizar $true })
function Monedas-De([string]$algo) { if ($algo -and $ajustes.monedas_algoritmo.Contains($algo)) { return [string]$ajustes.monedas_algoritmo[$algo] }; return '-' }
$btnAlg.Add_Click({
    $t = "Monedas que puede minar cada algoritmo del minero:`r`n`r`n"
    foreach ($k in $ajustes.monedas_algoritmo.Keys) { $t += $k + ':  ' + $ajustes.monedas_algoritmo[$k] + "`r`n" }
    $t += "`r`nLa tabla consulta la red de una moneda por algoritmo (columna 'Moneda consultada'). Para otra moneda del mismo algoritmo, cambia el pool y la wallet en la pestana Minero. La lista se puede ampliar en monitor\monitor_config.json (monedas_algoritmo)."
    [void][System.Windows.Forms.MessageBox]::Show($t, 'Monedas por algoritmo', 'OK', 'Information')
})
$btnApi.Add_Click({ $cambio = Api-Ventana $monedas; if ($cambio) { Actualizar $false } })
$btnWal.Add_Click({ $f = Exportar-Wallets; $monLbl.Text = 'Guardado en ' + $f; Start-Process notepad.exe $f })

$monTimer = New-Object System.Windows.Forms.Timer
$monTimer.Interval = [int]([double]$ajustes.minutos_refresco * 60000)
$monTimer.Add_Tick({ Actualizar $false })
function Monitor-Iniciar { if (-not $script:monIniciado) { $script:monIniciado = $true; $monTimer.Start(); Actualizar $Prueba.IsPresent } }
function Monitor-Cerrar { $monTimer.Stop(); $icono.Visible = $false; $icono.Dispose() }
if ($monSolo) {
    $monForm.Add_Shown({ Monitor-Iniciar })
    $monForm.Add_FormClosed({ Monitor-Cerrar })
    [void]$monForm.ShowDialog()
} else {
    # en la pestana: primera consulta 2 s despues de abrir el panel (para que la ventana salga enseguida)
    $monArranque = New-Object System.Windows.Forms.Timer
    $monArranque.Interval = 2000
    $monArranque.Add_Tick({ $monArranque.Stop(); Monitor-Iniciar })
    $monArranque.Start()
}
