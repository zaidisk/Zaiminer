# panel_gpus.ps1 - pestana "GPUs" del panel v5 (se carga con dot-source desde minero_gui5.ps1, con $gpuContenedor = la pagina).
# - Detecta las GPU NVIDIA con nvidia-smi (numero, nombre, vatios actuales, minimo y maximo).
# - Modo 1: todas las GPU marcadas minan el algoritmo elegido en la pestana Minero.
#   Modo 2: cada GPU mina el algoritmo que se elija en su fila (pool y wallet salen de la pestana Minero de ese algoritmo).
# - Vatios y reloj maximo por tarjeta (vacio = no tocar). El lanzador los pone al empezar y los devuelve al parar.
# - "Prueba": anade una segunda copia sobre la GPU 0, para probar el modo de varias GPU con una sola tarjeta.
# La eleccion se guarda en gpus_config.json (sin wallets).
# Ojo: este archivo y monitor_redN.ps1 se cargan en el mismo ambito; aqui todas las variables llevan el prefijo gpu para no pisarse (el monitor usa $grid).

$script:gpusLista = @()      # filas: @{ gpu; nombre; min; max; actual; copia }
$script:gpusRefresco = [DateTime]::MinValue

function Buscar-NvidiaSmi {
    $c = Get-Command 'nvidia-smi' -ErrorAction SilentlyContinue
    if ($c) { return $c.Source }
    foreach ($r in @("$env:SystemRoot\System32\nvidia-smi.exe", "$env:ProgramFiles\NVIDIA Corporation\NVSMI\nvidia-smi.exe")) { if (Test-Path $r) { return $r } }
    return $null
}
function Numero-Smi([string]$s) {
    $d = 0.0
    if ([double]::TryParse($s.Trim(), [Globalization.NumberStyles]::Float, [Globalization.CultureInfo]::InvariantCulture, [ref]$d)) { return [int][Math]::Round($d) }
    return 0
}

# ---------- controles ----------
$gpuPag = $gpuContenedor
$gpuPag.Controls.Add((Nueva-Etiqueta 'GPUs y potencia' 16 12 400 28 $cTexto 13 $true))
$gpuPag.Controls.Add((Nueva-Etiqueta 'Marca las GPU que quieres usar. Vatios y reloj vacios = la tarjeta queda como esta. Poner vatios o reloj pide permiso de administrador al iniciar.' 16 42 788 36 $cGris 9 $false))

$gpuRbMismo = New-Object System.Windows.Forms.RadioButton
$gpuRbMismo.Text = 'Todas con el algoritmo elegido en la pestana Minero'
$gpuRbMismo.Location = New-Object System.Drawing.Point(16, 80); $gpuRbMismo.Size = New-Object System.Drawing.Size(390, 24); $gpuRbMismo.Checked = $true
$gpuPag.Controls.Add($gpuRbMismo)
$gpuRbCada = New-Object System.Windows.Forms.RadioButton
$gpuRbCada.Text = 'Cada GPU con su propio algoritmo'
$gpuRbCada.Location = New-Object System.Drawing.Point(410, 80); $gpuRbCada.Size = New-Object System.Drawing.Size(300, 24)
$gpuPag.Controls.Add($gpuRbCada)

$gpuBtnDetectar = New-Object System.Windows.Forms.Button
$gpuBtnDetectar.Text = 'Detectar GPUs'; $gpuBtnDetectar.Location = New-Object System.Drawing.Point(16, 112); $gpuBtnDetectar.Size = New-Object System.Drawing.Size(150, 30)
$gpuBtnDetectar.FlatStyle = 'Flat'; $gpuBtnDetectar.BackColor = $cAzul; $gpuBtnDetectar.ForeColor = [System.Drawing.Color]::White
$gpuPag.Controls.Add($gpuBtnDetectar)
$gpuChkCopia = New-Object System.Windows.Forms.CheckBox
$gpuChkCopia.Text = 'Prueba: anadir una 2a copia sobre la GPU 0 (simula dos GPU)'
$gpuChkCopia.Location = New-Object System.Drawing.Point(180, 116); $gpuChkCopia.Size = New-Object System.Drawing.Size(460, 24)
$gpuPag.Controls.Add($gpuChkCopia)

$gpuGrid = New-Object System.Windows.Forms.DataGridView
$gpuGrid.Location = New-Object System.Drawing.Point(16, 152); $gpuGrid.Size = New-Object System.Drawing.Size(788, 330)
$gpuGrid.Anchor = 'Top,Left,Right'
$gpuGrid.AllowUserToAddRows = $false; $gpuGrid.AllowUserToDeleteRows = $false; $gpuGrid.RowHeadersVisible = $false
$gpuGrid.SelectionMode = 'CellSelect'; $gpuGrid.BackgroundColor = $cTarjeta; $gpuGrid.BorderStyle = 'None'
$gpuGrid.EditMode = 'EditOnEnter'
$gpuGrid.AutoSizeColumnsMode = 'Fill'
function Nueva-Col($tipo, $nombre, $titulo, $peso, $soloLectura) {
    $col = New-Object $tipo
    $col.Name = $nombre; $col.HeaderText = $titulo; $col.FillWeight = $peso; $col.ReadOnly = $soloLectura
    [void]$gpuGrid.Columns.Add($col)
    return $col
}
[void](Nueva-Col 'System.Windows.Forms.DataGridViewCheckBoxColumn' 'usar' 'Usar' 35 $false)
[void](Nueva-Col 'System.Windows.Forms.DataGridViewTextBoxColumn' 'gpu' 'GPU' 30 $true)
[void](Nueva-Col 'System.Windows.Forms.DataGridViewTextBoxColumn' 'nombre' 'Tarjeta' 120 $true)
$gpuColAlgo = Nueva-Col 'System.Windows.Forms.DataGridViewComboBoxColumn' 'algo' 'Algoritmo' 130 $false
foreach ($k in $algos.Keys) { [void]$gpuColAlgo.Items.Add([string]$k) }
$gpuColAlgo.FlatStyle = 'Flat'
[void](Nueva-Col 'System.Windows.Forms.DataGridViewTextBoxColumn' 'vatios' 'Vatios' 45 $false)
[void](Nueva-Col 'System.Windows.Forms.DataGridViewTextBoxColumn' 'rango' 'Min-max (ahora)' 75 $true)
[void](Nueva-Col 'System.Windows.Forms.DataGridViewTextBoxColumn' 'reloj' 'Reloj max MHz' 55 $false)
[void](Nueva-Col 'System.Windows.Forms.DataGridViewTextBoxColumn' 'vel' 'Velocidad' 70 $true)
[void](Nueva-Col 'System.Windows.Forms.DataGridViewTextBoxColumn' 'shares' 'Acept / rech' 55 $true)
[void](Nueva-Col 'System.Windows.Forms.DataGridViewTextBoxColumn' 'estado' 'Estado' 70 $true)
$gpuGrid.Add_DataError({ param($s, $e) $e.ThrowException = $false })
$gpuGrid.Add_CurrentCellDirtyStateChanged({ if ($gpuGrid.IsCurrentCellDirty) { [void]$gpuGrid.CommitEdit('CurrentCellChange') } })
$gpuPag.Controls.Add($gpuGrid)

$lblGpuNota = Nueva-Etiqueta '' 16 490 788 60 $cGris 9 $false
$lblGpuNota.Anchor = 'Top,Left,Right'
$gpuPag.Controls.Add($lblGpuNota)
$gpuPag.Controls.Add((Nueva-Etiqueta "Comision del autor: $COMISION_MIN_TXT min de cada $COMISION_CADA_MIN min de minado (~$COMISION_PCT_TXT%): tus GPUs minan lo que elija el autor. Se marca en ambar en el registro." 16 552 788 24 $cGris 9 $false))

# ---------- guardar / leer eleccion ----------
function Gpus-Guardar {
    $filas = @()
    foreach ($r in $gpuGrid.Rows) {
        $filas += @{ gpu = [string]$r.Cells['gpu'].Value; nombre = [string]$r.Cells['nombre'].Value; usar = [bool]$r.Cells['usar'].Value
                     algo = [string]$r.Cells['algo'].Value; vatios = [string]$r.Cells['vatios'].Value; reloj = [string]$r.Cells['reloj'].Value }
    }
    $o = @{ modo = $(if ($gpuRbCada.Checked) { 'cada' } else { 'mismo' }); copia = $gpuChkCopia.Checked; filas = $filas }
    try { $o | ConvertTo-Json -Depth 4 | Set-Content -Path $gpusFile -Encoding UTF8 } catch { }
}
$script:gpusGuardado = $null
if (Test-Path $gpusFile) { try { $script:gpusGuardado = Get-Content $gpusFile -Raw | ConvertFrom-Json } catch { } }
if ($script:gpusGuardado) {
    if ($script:gpusGuardado.modo -eq 'cada') { $gpuRbCada.Checked = $true }
    if ($script:gpusGuardado.copia) { $gpuChkCopia.Checked = $true }
}

function Aplicar-Modo {
    $cada = $gpuRbCada.Checked
    $gpuColAlgo.ReadOnly = -not $cada
    foreach ($r in $gpuGrid.Rows) {
        if (-not $cada) { $r.Cells['algo'].Value = [string]$combo.SelectedItem }
        $r.Cells['algo'].Style.ForeColor = if ($cada) { $cTexto } else { $cGris }
    }
}

# ---------- deteccion ----------
function Gpus-Detectar {
    $script:gpusGuardado = $null
    if (Test-Path $gpusFile) { try { $script:gpusGuardado = Get-Content $gpusFile -Raw | ConvertFrom-Json } catch { } }
    $gpuGrid.Rows.Clear(); $script:gpusLista = @()
    $smi = Buscar-NvidiaSmi
    $lineas = @()
    if ($smi) {
        try { $lineas = @(& $smi --query-gpu=index,name,power.limit,power.min_limit,power.max_limit --format=csv,noheader,nounits 2>$null) } catch { }
    }
    foreach ($l in $lineas) {
        $p = ([string]$l).Split(',')
        if ($p.Length -lt 5) { continue }
        $script:gpusLista += @{ gpu = [int]$p[0].Trim(); nombre = $p[1].Trim(); actual = (Numero-Smi $p[2]); min = (Numero-Smi $p[3]); max = (Numero-Smi $p[4]); copia = $false }
    }
    if ($script:gpusLista.Count -eq 0) {
        $lblGpuNota.Text = 'No se encontraron GPU NVIDIA con nvidia-smi. Se minara con la GPU 0 sin tocar vatios ni reloj.'
        $lblGpuNota.ForeColor = $cRojo
        return
    }
    if ($gpuChkCopia.Checked) {
        $g0 = $script:gpusLista[0]
        $script:gpusLista += @{ gpu = $g0.gpu; nombre = "$($g0.nombre) (copia de prueba)"; actual = $g0.actual; min = $g0.min; max = $g0.max; copia = $true }
    }
    $fila = 0
    foreach ($g in $script:gpusLista) {
        $i = $gpuGrid.Rows.Add()
        $r = $gpuGrid.Rows[$i]
        $r.Cells['usar'].Value = $true
        $r.Cells['gpu'].Value = [string]$g.gpu
        $r.Cells['nombre'].Value = $g.nombre
        $r.Cells['algo'].Value = [string]$combo.SelectedItem
        $r.Cells['vatios'].Value = ''
        $r.Cells['reloj'].Value = ''
        $r.Cells['rango'].Value = if ($g.max -gt 0) { "$($g.min)-$($g.max) ($($g.actual))" } else { 'n/d' }
        $r.Cells['vel'].Value = '-'; $r.Cells['shares'].Value = ''; $r.Cells['estado'].Value = ''
        $r.Tag = $fila   # id de la tarea = numero de fila (sale en el registro como [GPUid])
        # recuperar lo guardado para esta fila (misma GPU y mismo nombre)
        if ($script:gpusGuardado -and $script:gpusGuardado.filas) {
            foreach ($s in @($script:gpusGuardado.filas)) {
                if ([string]$s.gpu -eq [string]$g.gpu -and [string]$s.nombre -eq $g.nombre) {
                    $r.Cells['usar'].Value = [bool]$s.usar
                    $algoGuardado = [string]$s.algo
                    if ($nombresViejos -and $nombresViejos.ContainsKey($algoGuardado)) { $algoGuardado = $nombresViejos[$algoGuardado] }
                    if ($algoGuardado -and $gpuColAlgo.Items.Contains($algoGuardado)) { $r.Cells['algo'].Value = $algoGuardado }
                    $r.Cells['vatios'].Value = [string]$s.vatios; $r.Cells['reloj'].Value = [string]$s.reloj
                }
            }
        }
        $fila++
    }
    $lblGpuNota.ForeColor = $cGris
    $lblGpuNota.Text = "$(@($script:gpusLista | Where-Object { -not $_.copia }).Count) GPU encontrada(s). Cada GPU sale en el registro como [GPU0], [GPU1]... y en el pool como worker-g0, worker-g1..."
    Aplicar-Modo
}

# ---------- lo que usa el boton Iniciar ----------
# Devuelve una lista de @{ id; gpu; algo; potencia; reloj } con las filas marcadas.
function Gpus-Tareas([string]$algoPrincipal) {
    [void]$gpuGrid.EndEdit()
    Gpus-Guardar
    $r2 = @()
    foreach ($r in $gpuGrid.Rows) {
        if (-not [bool]$r.Cells['usar'].Value) { continue }
        $algo = if ($gpuRbCada.Checked -and [string]$r.Cells['algo'].Value -ne '') { [string]$r.Cells['algo'].Value } else { $algoPrincipal }
        $w = 0; $mhz = 0
        [void][int]::TryParse(([string]$r.Cells['vatios'].Value).Trim(), [ref]$w)
        [void][int]::TryParse(([string]$r.Cells['reloj'].Value).Trim(), [ref]$mhz)
        $r2 += @{ id = [int]$r.Tag; gpu = [int]$r.Cells['gpu'].Value; algo = $algo; potencia = $w; reloj = $mhz }
    }
    if ($gpuGrid.Rows.Count -gt 0 -and $r2.Count -eq 0) { [System.Windows.Forms.MessageBox]::Show('No hay ninguna GPU marcada en la pestana GPUs: se usara la GPU 0.', 'GPUs') | Out-Null }
    return $r2
}
# Pone velocidad, shares y estado de cada fila (lo llama el panel al leer el registro; como mucho 1 vez por segundo).
function Gpus-Refrescar {
    if (((Get-Date) - $script:gpusRefresco).TotalMilliseconds -lt 1000) { return }
    $script:gpusRefresco = Get-Date
    foreach ($r in $gpuGrid.Rows) {
        $id = [int]$r.Tag
        if (-not $script:gpuEst.ContainsKey($id)) { continue }
        $e = $script:gpuEst[$id]
        $r.Cells['vel'].Value = if ($e.vel -gt 0) { Formato-Vel $e.vel $e.unidad } else { '-' }
        $r.Cells['shares'].Value = "$(Total-Gpu $e 'acc') / $(Total-Gpu $e 'rech')"
        $r.Cells['estado'].Value = if ($e.comision) { 'comision (autor)' } else { 'minando' }
        $r.Cells['estado'].Style.ForeColor = if ($e.comision) { [System.Drawing.Color]::FromArgb(176, 120, 0) } else { $cVerde }
    }
}
# Mientras se mina no se puede cambiar la eleccion.
function Gpus-Bloquear([bool]$b) {
    $gpuGrid.ReadOnly = $b; $gpuBtnDetectar.Enabled = -not $b; $gpuRbMismo.Enabled = -not $b; $gpuRbCada.Enabled = -not $b; $gpuChkCopia.Enabled = -not $b
    if (-not $b) {
        foreach ($c in @('gpu', 'nombre', 'rango', 'vel', 'shares', 'estado')) { $gpuGrid.Columns[$c].ReadOnly = $true }
        Aplicar-Modo
        foreach ($r in $gpuGrid.Rows) { $r.Cells['estado'].Value = '' }
    }
}

# ---------- eventos ----------
$gpuBtnDetectar.Add_Click({ Gpus-Guardar; Gpus-Detectar })
$gpuChkCopia.Add_CheckedChanged({ Gpus-Guardar; Gpus-Detectar })
$gpuRbCada.Add_CheckedChanged({ Aplicar-Modo })
$combo.Add_SelectedIndexChanged({ if (-not $gpuRbCada.Checked) { Aplicar-Modo } })
Gpus-Detectar
