@echo off
REM Monitor de red y saldos v10 en ventana propia.
powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0monitor_red10.ps1"
