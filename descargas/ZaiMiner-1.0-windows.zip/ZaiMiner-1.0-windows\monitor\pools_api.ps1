# pools_api.ps1 - Configuracion de la API de los pools (para la pestana "Red y saldos")
# Lo carga monitor_red7.ps1 (o posterior) con '. pools_api.ps1'. No abre nada por si solo.
#
# Que hace:
#   - Guarda en monitor\pools_api.json una lista de pools con su API: tipo, host, wallet, clave API y donde leer
#     cada dato (saldo, pagado, tu hashrate, workers) en la respuesta JSON.
#   - Las claves API se guardan CIFRADAS con DPAPI de Windows: solo tu usuario de Windows en este PC puede leerlas.
#     Nunca salen del PC salvo hacia la URL del pool que tu escribas.
#   - Trae plantillas para los tipos de pool mas comunes (MPOS/Suprnova, MiningCore, YIIMP/zpool, NOMP,
#     cryptonote-nodejs-pool, Luckpool) y uno "Personalizado" para cualquier otra API JSON.
#   - Ventana de configuracion con boton "Probar" que muestra la respuesta del pool (con la clave tapada).
#
# Marcadores que se pueden usar en las URL y en la cabecera:
#   {host} {wallet} {worker} {api_key} {moneda}
# Rutas JSON: a.b.c   lista[0]   * = todos los hijos (se suman)   a+b = suma de dos rutas
#   #ruta = cuantos elementos hay (p.ej. #performance.workers = numero de workers)
#   2:ruta = leer de la respuesta de la URL 2 en vez de la URL 1

$apiArchivo = Join-Path $monDir 'pools_api.json'

# ---------- plantillas ----------
$apiTipos = [ordered]@{
    'MPOS (Suprnova y similares)' = [ordered]@{
        url1 = 'https://{host}/index.php?page=api&action=getuserbalance&api_key={api_key}'
        url2 = 'https://{host}/index.php?page=api&action=getuserstatus&api_key={api_key}'
        cabecera = ''; ruta_saldo = 'getuserbalance.data.confirmed+getuserbalance.data.unconfirmed'; ruta_pagado = ''
        ruta_hashrate = '2:getuserstatus.data.hashrate'; ruta_workers = ''; factor_saldo = 1; factor_hashrate = 1000
        ayuda = 'Necesita clave API (en la web del pool: Mi cuenta > Editar cuenta > API Key). MPOS da el hashrate en kH/s (factor 1000).' }
    'MiningCore' = [ordered]@{
        url1 = 'https://{host}/api/pools/{moneda}/miners/{wallet}'; url2 = ''
        cabecera = ''; ruta_saldo = 'pendingBalance'; ruta_pagado = 'totalPaid'
        ruta_hashrate = 'performance.workers.*.hashrate'; ruta_workers = '#performance.workers'; factor_saldo = 1; factor_hashrate = 1
        ayuda = 'Sin clave. En "Id moneda" va el id del pool (ver https://host/api/pools, campo id).' }
    'YIIMP (zpool, zergpool...)' = [ordered]@{
        url1 = 'https://{host}/api/walletEx?address={wallet}'; url2 = ''
        cabecera = ''; ruta_saldo = 'unpaid'; ruta_pagado = 'paid24h'
        ruta_hashrate = 'miners.*.accepted'; ruta_workers = '#miners'; factor_saldo = 1; factor_hashrate = 1
        ayuda = 'Sin clave. Host = dominio de la web (zpool.ca), no el del stratum. "Pagado" = ultimas 24 h. Estos pools limitan las consultas: no bajar de 5 min.' }
    'NOMP / s-nomp' = [ordered]@{
        url1 = 'https://{host}/api/worker_stats?{wallet}'; url2 = ''
        cabecera = ''; ruta_saldo = 'balance+immature'; ruta_pagado = 'paid'
        ruta_hashrate = 'totalHash'; ruta_workers = '#workers'; factor_saldo = 1; factor_hashrate = 1
        ayuda = 'Sin clave.' }
    'cryptonote-nodejs-pool' = [ordered]@{
        url1 = 'https://{host}/api/stats_address?address={wallet}&longpoll=false'; url2 = ''
        cabecera = ''; ruta_saldo = 'stats.balance'; ruta_pagado = 'stats.paid'
        ruta_hashrate = 'stats.hashrate'; ruta_workers = '#workers'; factor_saldo = 1e-8; factor_hashrate = 1
        ayuda = 'Sin clave. El saldo viene en unidades minimas: ajusta "Factor saldo" a la moneda (Xelis 1e-8, Monero 1e-12).' }
    '2Miners' = [ordered]@{
        url1 = 'https://{host}/api/accounts/{wallet}'; url2 = ''
        cabecera = ''; ruta_saldo = 'stats.balance+stats.immature'; ruta_pagado = 'stats.paid'
        ruta_hashrate = 'currentHashrate'; ruta_workers = 'workersOnline'; factor_saldo = 1e-9; factor_hashrate = 1
        ayuda = 'Sin clave. Host = etc.2miners.com, rvn.2miners.com... Saldo en 1e-9 (ETC/ETHW); en RVN prueba 1e-8 y compara con la web.' }
    'Luckpool' = [ordered]@{
        url1 = 'https://luckpool.net/{moneda}/miner/{wallet}'; url2 = ''
        cabecera = ''; ruta_saldo = 'balance+immature'; ruta_pagado = 'paid'
        ruta_hashrate = 'hashrateSols'; ruta_workers = '#workers'; factor_saldo = 1; factor_hashrate = 1
        ayuda = 'Sin clave. "Id moneda" = verus. Pulsa Probar y revisa el nombre del campo de hashrate.' }
    'Personalizado' = [ordered]@{
        url1 = ''; url2 = ''; cabecera = ''; ruta_saldo = ''; ruta_pagado = ''; ruta_hashrate = ''; ruta_workers = ''
        factor_saldo = 1; factor_hashrate = 1
        ayuda = 'Cualquier API que devuelva JSON. Si el pool pide la clave en una cabecera, ponla asi: X-API-KEY: {api_key}' }
}
$apiCampos = @('url1','url2','cabecera','ruta_saldo','ruta_pagado','ruta_hashrate','ruta_workers','factor_saldo','factor_hashrate')

# ---------- cifrado de la clave (DPAPI, solo este usuario en este PC) ----------
function Api-Cifrar([string]$txt) {
    if (-not $txt) { return '' }
    try { return ('dpapi:' + (ConvertTo-SecureString $txt -AsPlainText -Force | ConvertFrom-SecureString)) }
    catch { return ('b64:' + [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($txt))) }   # solo si no hay DPAPI (no Windows)
}
function Api-Descifrar([string]$c) {
    if (-not $c) { return '' }
    try {
        if ($c.StartsWith('dpapi:')) {
            $s = ConvertTo-SecureString $c.Substring(6)
            $b = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($s)
            try { return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($b) } finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($b) }
        }
        if ($c.StartsWith('b64:')) { return [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($c.Substring(4))) }
    } catch { }
    return ''   # cifrada en otro PC u otro usuario: hay que volver a escribirla
}

# ---------- lista de pools ----------
function Api-NuevaEntrada([string]$tipo) {
    if (-not $apiTipos.Contains($tipo)) { $tipo = 'Personalizado' }
    $e = [ordered]@{ activo = $true; nombre = 'Nuevo pool'; moneda = ''; tipo = $tipo; host = ''; wallet = ''; worker = ''; api_key = '' }
    foreach ($k in $apiCampos) { $e[$k] = $apiTipos[$tipo][$k] }
    return $e
}
function Api-Cargar {
    $lista = New-Object System.Collections.Generic.List[object]
    if (-not (Test-Path $apiArchivo)) { return ,$lista }
    try {
        $j = Get-Content $apiArchivo -Raw -Encoding UTF8 | ConvertFrom-Json
        foreach ($p in @($j.pools)) {
            if ($null -eq $p) { continue }
            $e = Api-NuevaEntrada ([string]$p.tipo)
            foreach ($k in @('nombre','moneda','tipo','host','wallet','worker','url1','url2','cabecera','ruta_saldo','ruta_pagado','ruta_hashrate','ruta_workers')) {
                if ($null -ne $p.$k) { $e[$k] = [string]$p.$k }
            }
            foreach ($k in @('factor_saldo','factor_hashrate')) { if ($null -ne $p.$k) { $e[$k] = [double]$p.$k } }
            if ($null -ne $p.activo) { $e.activo = [bool]$p.activo }
            $e.api_key = Api-Descifrar ([string]$p.api_key_cifrada)
            $e['cifrada_orig'] = [string]$p.api_key_cifrada
            $e['clave_ilegible'] = ([string]$p.api_key_cifrada -and -not $e.api_key)
            $lista.Add($e)
        }
    } catch { }
    return ,$lista   # la coma evita que una lista de 1 elemento se convierta en el elemento
}
function Api-Guardar($lista) {
    $pools = @()
    foreach ($e in $lista) {
        $o = [ordered]@{}
        foreach ($k in @('activo','nombre','moneda','tipo','host','wallet','worker') + $apiCampos) { $o[$k] = $e[$k] }
        $o['api_key_cifrada'] = Api-Cifrar $e.api_key
        if (-not $e.api_key -and $e.clave_ilegible) { $o['api_key_cifrada'] = $e.cifrada_orig }   # no borrar una clave de otro PC
        $pools += $o
    }
    $doc = [ordered]@{
        nota = 'Configuracion de API de pools. Las claves estan cifradas (DPAPI): solo se pueden leer con tu usuario de Windows en este PC. No compartas este archivo.'
        pools = $pools
    }
    ($doc | ConvertTo-Json -Depth 5) | Set-Content -Path $apiArchivo -Encoding UTF8
}

# crea entradas a partir de los pools de minero_config.json (solo las que aun no existan para esa moneda)
function Api-Detectar($lista, $monedasLista, $clavesuprnova) {
    $nuevas = 0
    foreach ($m in $monedasLista) {
        $pool = Dato $m.id 'pool'; if (-not $pool) { continue }
        $existe = $false; foreach ($e in $lista) { if ($e.moneda -eq $m.id) { $existe = $true } }
        if ($existe) { continue }
        $h = Host-Pool $pool
        $e = $null
        if ($h -like '*suprnova.cc') {
            $e = Api-NuevaEntrada 'MPOS (Suprnova y similares)'; $e.host = $h; $e.api_key = [string]$clavesuprnova
        } elseif ($h -like '*zpool.ca') {
            $e = Api-NuevaEntrada 'YIIMP (zpool, zergpool...)'; $e.host = 'zpool.ca'
        } elseif ($h -like '*zergpool.com') {
            $e = Api-NuevaEntrada 'YIIMP (zpool, zergpool...)'; $e.host = 'zergpool.com'
        } elseif ($h -like '*.2miners.com') {
            $e = Api-NuevaEntrada '2Miners'; $e.host = $h -replace '^(eu|us|asia)-', ''
            if ($m.id -eq 'rvn') { $e.factor_saldo = 1e-8 }
        } elseif ($h -like '*luckpool.net') {
            $e = Api-NuevaEntrada 'Luckpool'; $e.host = 'luckpool.net'
        } elseif ($h -like '*pepepow.net') {
            $e = Api-NuevaEntrada 'Personalizado'; $e.host = 'pool.pepepow.net'
            $e.url1 = 'https://pool.pepepow.net/api/miner/{wallet}'; $e.ruta_pagado = 'totalPaidManual'
        } else { continue }   # pools sin API conocida (nushypool, mining4people...): se pueden anadir a mano
        $e.moneda = $m.id; $e.nombre = $m.nombre + ' - ' + $e.host
        if ($m.id -eq 'verus') { $e.url1 = $e.url1 -replace '\{moneda\}', 'verus' }
        $lista.Add($e); $nuevas++
    }
    return $nuevas
}

# ---------- leer rutas en el JSON ----------
function Api-Num($v) {
    if ($null -eq $v) { return $null }
    if ($v -is [bool]) { return $null }
    if ($v -is [string]) {
        $d = 0.0
        if ([double]::TryParse($v.Trim(), [Globalization.NumberStyles]::Float, [Globalization.CultureInfo]::InvariantCulture, [ref]$d)) { return $d }
        return $null
    }
    try { return [double]$v } catch { return $null }
}
function Api-Hijos($o) {
    if ($null -eq $o) { return @() }
    if ($o -is [string]) { return @() }
    if ($o -is [System.Collections.IDictionary]) { return @($o.Values) }
    if ($o -is [System.ValueType]) { return @() }
    if ($o -is [System.Collections.IEnumerable]) { return @($o) }
    if ($o -is [System.Management.Automation.PSCustomObject]) { return @($o.PSObject.Properties | ForEach-Object { $_.Value }) }
    return @()
}
function Api-Nodos($obj, [string]$ruta) {
    $nodos = @(,$obj)
    if (-not $ruta) { return $nodos }
    foreach ($seg in ($ruta -split '\.')) {
        if ($seg -eq '') { continue }
        $sig = @()
        foreach ($n in $nodos) {
            if ($null -eq $n) { continue }
            if ($seg -eq '*') { $sig += Api-Hijos $n; continue }
            $nombre = $seg; $idx = $null
            if ($seg -match '^(.*)\[(\d+)\]$') { $nombre = $Matches[1]; $idx = [int]$Matches[2] }
            $v = $n
            if ($nombre) {
                if ($n -is [System.Collections.IDictionary]) { $v = $n[$nombre] }
                elseif ($n.PSObject.Properties[$nombre]) { $v = $n.PSObject.Properties[$nombre].Value }
                else { $v = $null }
            }
            if ($null -ne $idx -and $null -ne $v) { $arr = @($v); if ($idx -lt $arr.Count) { $v = $arr[$idx] } else { $v = $null } }
            if ($null -ne $v) { $sig += ,$v }
        }
        $nodos = $sig
    }
    return ,$nodos
}
# devuelve la suma de los valores encontrados, o $null si la ruta no lleva a ningun numero
function Api-Ruta($respuestas, [string]$expr) {
    if (-not $expr) { return $null }
    $total = 0.0; $alguno = $false
    foreach ($t in ($expr -split '\+')) {
        $t = $t.Trim(); if (-not $t) { continue }
        $resp = $respuestas[0]
        if ($t -match '^(\d):(.*)$') { $i = [int]$Matches[1] - 1; $t = $Matches[2]; $resp = if ($i -lt $respuestas.Count) { $respuestas[$i] } else { $null } }
        if ($null -eq $resp) { continue }
        if ($t.StartsWith('#')) {
            $lst = Api-Nodos $resp $t.Substring(1)
            $c = 0; foreach ($n in $lst) { $c += @(Api-Hijos $n).Count }
            $total += $c; $alguno = $true; continue
        }
        $lst = Api-Nodos $resp $t
        foreach ($n in $lst) {
            foreach ($x in @($n)) { $d = Api-Num $x; if ($null -ne $d) { $total += $d; $alguno = $true } }
        }
    }
    if ($alguno) { return $total } else { return $null }
}

# ---------- consultar un pool ----------
function Api-Rellenar([string]$txt, $e, [string]$wallet) {
    if (-not $txt) { return '' }
    $r = $txt.Replace('{host}', [string]$e.host).Replace('{moneda}', [string]$e.moneda)
    $r = $r.Replace('{wallet}', [Uri]::EscapeDataString($wallet)).Replace('{worker}', [Uri]::EscapeDataString([string]$e.worker))
    return $r.Replace('{api_key}', [string]$e.api_key)
}
function Api-Tapar([string]$txt, $e) {
    if ($e.api_key -and $txt) { $txt = $txt.Replace([string]$e.api_key, '***') ; $txt = $txt.Replace([Uri]::EscapeDataString([string]$e.api_key), '***') }
    return $txt
}
function Api-WalletDe($e) {
    if ($e.wallet) { return [string]$e.wallet }
    if ($e.moneda) { return (Dato $e.moneda 'wallet') }
    return ''
}
# devuelve @{ ok; saldo; pagado; hashrate; workers; error; crudo (texto con la clave tapada) }
function Api-Consultar($e) {
    $res = @{ ok = $false; saldo = $null; pagado = $null; hashrate = $null; workers = $null; error = ''; crudo = '' }
    $sb = New-Object System.Text.StringBuilder
    $w = Api-WalletDe $e
    $necesitaWallet = ("$($e.url1)$($e.url2)" -match '\{wallet\}')
    $necesitaClave  = ("$($e.url1)$($e.url2)$($e.cabecera)" -match '\{api_key\}')
    if (-not $e.url1) { $res.error = 'falta la URL 1'; return $res }
    if ($necesitaWallet -and -not $w) { $res.error = 'falta la wallet'; return $res }
    if ($necesitaClave -and -not $e.api_key) { $res.error = $(if ($e.clave_ilegible) { 'clave cifrada en otro PC: escribela de nuevo' } else { 'falta la clave API' }); return $res }
    $cab = @{ 'User-Agent' = 'Mozilla/5.0 monitor-minero'; 'Accept' = 'application/json' }
    if ($e.cabecera) {
        foreach ($l in ($e.cabecera -split ';')) { $p = $l.IndexOf(':'); if ($p -gt 0) { $cab[$l.Substring(0, $p).Trim()] = (Api-Rellenar $l.Substring($p + 1).Trim() $e $w) } }
    }
    $resp = @()
    foreach ($u in @($e.url1, $e.url2)) {
        if (-not $u) { continue }
        $url = Api-Rellenar $u $e $w
        if ($url -like 'http://*' -and $e.api_key -and $necesitaClave) { [void]$sb.AppendLine('AVISO: la clave API viaja sin cifrar (http://). Usa https si el pool lo permite.') }
        try {
            $r = Invoke-WebRequest -Uri $url -UseBasicParsing -TimeoutSec 15 -Headers $cab
            $t = Texto $r.Content
            [void]$sb.AppendLine('GET ' + (Api-Tapar $url $e))
            [void]$sb.AppendLine('    ' + (Api-Tapar $t.Substring(0, [Math]::Min(1500, $t.Length)) $e))
            $j = $null
            try { $j = $t | ConvertFrom-Json } catch { $res.error = 'la respuesta no es JSON' }
            $resp += ,$j
        } catch {
            $msg = $_.Exception.Message
            [void]$sb.AppendLine('GET ' + (Api-Tapar $url $e) + "`r`n    error: " + (Api-Tapar $msg $e))
            $res.error = 'error de conexion: ' + (Api-Tapar $msg $e)
            $resp += ,$null
        }
    }
    $fs = 1.0; if ($e.factor_saldo) { $fs = [double]$e.factor_saldo }
    $fh = 1.0; if ($e.factor_hashrate) { $fh = [double]$e.factor_hashrate }
    $v = Api-Ruta $resp $e.ruta_saldo;    if ($null -ne $v) { $res.saldo = $v * $fs }
    $v = Api-Ruta $resp $e.ruta_pagado;   if ($null -ne $v) { $res.pagado = $v * $fs }
    $v = Api-Ruta $resp $e.ruta_hashrate; if ($null -ne $v) { $res.hashrate = $v * $fh }
    $v = Api-Ruta $resp $e.ruta_workers;  if ($null -ne $v) { $res.workers = [int]$v }
    $res.ok = ($null -ne $res.saldo -or $null -ne $res.hashrate -or $null -ne $res.pagado)
    if (-not $res.ok -and -not $res.error) { $res.error = 'no se encontro ningun dato: revisa las rutas con Probar' }
    if ($res.ok) { $res.error = '' }
    $res.crudo = $sb.ToString()
    return $res
}
function Api-Resumen($r) {
    $p = @()
    if ($null -ne $r.saldo)    { $p += 'saldo = ' + (Fmt-N $r.saldo) }
    if ($null -ne $r.pagado)   { $p += 'pagado = ' + (Fmt-N $r.pagado) }
    if ($null -ne $r.hashrate) { $p += 'tu hashrate = ' + (Fmt-H $r.hashrate) }
    if ($null -ne $r.workers)  { $p += 'workers = ' + $r.workers }
    if ($r.error) { $p += 'ERROR: ' + $r.error }
    return ($p -join '   |   ')
}

# ---------- ventana de configuracion ----------
function Api-Ventana($monedasLista) {
    $lista = Api-Cargar
    $f = New-Object System.Windows.Forms.Form
    $f.Text = 'API de los pools'
    $f.ClientSize = New-Object System.Drawing.Size(980, 694)
    $f.StartPosition = 'CenterParent'; $f.Font = New-Object System.Drawing.Font('Segoe UI', 9.5)
    $f.BackColor = [System.Drawing.Color]::FromArgb(245, 246, 248); $f.MinimizeBox = $false

    $lb = New-Object System.Windows.Forms.ListBox
    $lb.Location = New-Object System.Drawing.Point(12, 12); $lb.Size = New-Object System.Drawing.Size(250, 480)
    $f.Controls.Add($lb)
    function Boton($t, $x, $y, $w) { $b = New-Object System.Windows.Forms.Button; $b.Text = $t; $b.Location = New-Object System.Drawing.Point($x, $y); $b.Size = New-Object System.Drawing.Size($w, 30); $f.Controls.Add($b); return $b }
    $bAdd = Boton 'Anadir' 12 500 80
    $bDel = Boton 'Quitar' 97 500 80
    $bDet = Boton 'Detectar' 182 500 80
    $tip = New-Object System.Windows.Forms.ToolTip
    $tip.SetToolTip($bDet, 'Crea entradas para los pools de tus monedas (minero_config.json) que tengan API conocida')

    $cx = 280; $y = 12; $ctl = @{}
    function Fila($etq, $clave, $tipoCtl, $w) {
        $l = New-Object System.Windows.Forms.Label; $l.Text = $etq; $l.Location = New-Object System.Drawing.Point($cx, ($script:apiY + 4)); $l.Size = New-Object System.Drawing.Size(130, 22)
        $l.ForeColor = [System.Drawing.Color]::FromArgb(108, 117, 125); $f.Controls.Add($l)
        $c = New-Object $tipoCtl; $c.Location = New-Object System.Drawing.Point(($cx + 135), $script:apiY); $c.Size = New-Object System.Drawing.Size($w, 26)
        $f.Controls.Add($c); $ctl[$clave] = $c; $script:apiY += 30
        return $c
    }
    $script:apiY = 12
    $chk = Fila 'Activo' 'activo' 'System.Windows.Forms.CheckBox' 30
    [void](Fila 'Nombre' 'nombre' 'System.Windows.Forms.TextBox' 300)
    $cbMon = Fila 'Moneda (id)' 'moneda' 'System.Windows.Forms.ComboBox' 160
    foreach ($m in $monedasLista) { [void]$cbMon.Items.Add($m.id) }
    $ctlIdMon = New-Object System.Windows.Forms.Label; $ctlIdMon.Location = New-Object System.Drawing.Point(($cx + 305), ($script:apiY - 26)); $ctlIdMon.Size = New-Object System.Drawing.Size(380, 22)
    $ctlIdMon.ForeColor = [System.Drawing.Color]::FromArgb(108, 117, 125); $ctlIdMon.Text = 'tambien vale como {moneda} en la URL'; $f.Controls.Add($ctlIdMon)
    $cbTipo = Fila 'Tipo de pool' 'tipo' 'System.Windows.Forms.ComboBox' 260
    $cbTipo.DropDownStyle = 'DropDownList'; foreach ($k in $apiTipos.Keys) { [void]$cbTipo.Items.Add($k) }
    [void](Fila 'Host (web/API)' 'host' 'System.Windows.Forms.TextBox' 300)
    [void](Fila 'Wallet / usuario' 'wallet' 'System.Windows.Forms.TextBox' 560)
    $lw = New-Object System.Windows.Forms.Label; $lw.Text = '(vacio = la wallet de esa moneda en el panel)'; $lw.Location = New-Object System.Drawing.Point(($cx + 135), ($script:apiY - 4)); $lw.Size = New-Object System.Drawing.Size(400, 18)
    $lw.ForeColor = [System.Drawing.Color]::FromArgb(108, 117, 125); $lw.Font = New-Object System.Drawing.Font('Segoe UI', 8); $f.Controls.Add($lw); $script:apiY += 14
    [void](Fila 'Worker' 'worker' 'System.Windows.Forms.TextBox' 160)
    $tKey = Fila 'Clave API' 'api_key' 'System.Windows.Forms.TextBox' 420
    $tKey.UseSystemPasswordChar = $true
    $chkVer = New-Object System.Windows.Forms.CheckBox; $chkVer.Text = 'ver'; $chkVer.Location = New-Object System.Drawing.Point(($cx + 565), ($script:apiY - 30)); $chkVer.Size = New-Object System.Drawing.Size(60, 24)
    $chkVer.Add_CheckedChanged({ $tKey.UseSystemPasswordChar = -not $chkVer.Checked }); $f.Controls.Add($chkVer)
    [void](Fila 'URL 1' 'url1' 'System.Windows.Forms.TextBox' 560)
    [void](Fila 'URL 2 (opcional)' 'url2' 'System.Windows.Forms.TextBox' 560)
    [void](Fila 'Cabecera (opc.)' 'cabecera' 'System.Windows.Forms.TextBox' 560)
    [void](Fila 'Ruta saldo' 'ruta_saldo' 'System.Windows.Forms.TextBox' 380)
    [void](Fila 'Ruta pagado' 'ruta_pagado' 'System.Windows.Forms.TextBox' 380)
    [void](Fila 'Ruta tu hashrate' 'ruta_hashrate' 'System.Windows.Forms.TextBox' 380)
    [void](Fila 'Ruta workers' 'ruta_workers' 'System.Windows.Forms.TextBox' 380)
    $tFs = Fila 'Factor saldo' 'factor_saldo' 'System.Windows.Forms.TextBox' 90
    $tFh = New-Object System.Windows.Forms.TextBox; $tFh.Location = New-Object System.Drawing.Point(($cx + 375), ($script:apiY - 30)); $tFh.Size = New-Object System.Drawing.Size(90, 26); $f.Controls.Add($tFh); $ctl['factor_hashrate'] = $tFh
    $lFh = New-Object System.Windows.Forms.Label; $lFh.Text = 'Factor hashrate'; $lFh.Location = New-Object System.Drawing.Point(($cx + 260), ($script:apiY - 26)); $lFh.Size = New-Object System.Drawing.Size(110, 22)
    $lFh.ForeColor = [System.Drawing.Color]::FromArgb(108, 117, 125); $f.Controls.Add($lFh)

    $ayuda = New-Object System.Windows.Forms.Label
    $ayuda.Location = New-Object System.Drawing.Point($cx, $script:apiY); $ayuda.Size = New-Object System.Drawing.Size(690, 40)
    $ayuda.ForeColor = [System.Drawing.Color]::FromArgb(13, 110, 253); $f.Controls.Add($ayuda)

    $salida = New-Object System.Windows.Forms.TextBox
    $salida.Multiline = $true; $salida.ScrollBars = 'Both'; $salida.WordWrap = $false; $salida.ReadOnly = $true
    $salida.Font = New-Object System.Drawing.Font('Consolas', 8.5)
    $salida.Location = New-Object System.Drawing.Point(12, 548); $salida.Size = New-Object System.Drawing.Size(956, 100)
    $salida.Anchor = 'Top,Left,Right,Bottom'
    $salida.Text = 'Marcadores: {host} {wallet} {worker} {api_key} {moneda}.  Rutas: a.b.c  lista[0]  * (suma todos)  a+b  #ruta (cuenta)  2:ruta (de la URL 2).'
    $f.Controls.Add($salida)
    $bProb = Boton 'Probar' 12 656 110
    $bGuar = Boton 'Guardar' 750 656 105
    $bCerr = Boton 'Cerrar' 863 656 105
    foreach ($b in @($bProb, $bGuar, $bCerr)) { $b.Anchor = 'Bottom,Left' }
    $bGuar.Anchor = 'Bottom,Right'; $bCerr.Anchor = 'Bottom,Right'
    $lblG = New-Object System.Windows.Forms.Label; $lblG.Location = New-Object System.Drawing.Point(135, 662); $lblG.Size = New-Object System.Drawing.Size(600, 22)
    $lblG.Anchor = 'Bottom,Left'; $lblG.ForeColor = [System.Drawing.Color]::FromArgb(25, 135, 84); $f.Controls.Add($lblG)

    $script:apiSel = -1; $script:apiCargando = $false; $script:apiCambios = $false
    $refrescarLista = {
        $script:apiCargando = $true
        $lb.Items.Clear()
        foreach ($e in $lista) { [void]$lb.Items.Add(($(if ($e.activo) { '' } else { '(off) ' }) + $e.nombre)) }
        $script:apiCargando = $false
    }
    $aFormulario = {
        param($e)
        $script:apiCargando = $true
        $chk.Checked = [bool]$e.activo
        foreach ($k in @('nombre','host','wallet','worker','api_key') + $apiCampos) { $ctl[$k].Text = [string]$e[$k] }
        $cbMon.Text = [string]$e.moneda
        $cbTipo.SelectedItem = $(if ($apiTipos.Contains($e.tipo)) { $e.tipo } else { 'Personalizado' })
        $ayuda.Text = $apiTipos[[string]$cbTipo.SelectedItem].ayuda
        if ($e.clave_ilegible) { $ayuda.Text = 'La clave guardada se cifro en otro PC o con otro usuario de Windows: escribela de nuevo. ' + $ayuda.Text }
        $script:apiCargando = $false
    }
    $deFormulario = {
        if ($script:apiSel -lt 0 -or $script:apiSel -ge $lista.Count) { return }
        $e = $lista[$script:apiSel]
        $e.activo = $chk.Checked
        foreach ($k in @('nombre','host','wallet','worker','api_key','url1','url2','cabecera','ruta_saldo','ruta_pagado','ruta_hashrate','ruta_workers')) { $e[$k] = $ctl[$k].Text.Trim() }
        $e.moneda = $cbMon.Text.Trim(); $e.tipo = [string]$cbTipo.SelectedItem
        foreach ($k in @('factor_saldo','factor_hashrate')) { $d = Api-Num $ctl[$k].Text; $e[$k] = $(if ($null -ne $d -and $d -ne 0) { $d } else { 1.0 }) }
        if ($e.api_key) { $e.clave_ilegible = $false }
    }
    $lb.Add_SelectedIndexChanged({
        if ($script:apiCargando) { return }
        & $deFormulario
        $script:apiSel = $lb.SelectedIndex
        if ($script:apiSel -ge 0) { & $aFormulario $lista[$script:apiSel] }
    })
    $cbTipo.Add_SelectedIndexChanged({
        if ($script:apiCargando -or $script:apiSel -lt 0) { return }
        $t = $apiTipos[[string]$cbTipo.SelectedItem]
        foreach ($k in $apiCampos) { $ctl[$k].Text = [string]$t[$k] }
        $ayuda.Text = $t.ayuda
    })
    $bAdd.Add_Click({
        & $deFormulario
        $lista.Add((Api-NuevaEntrada 'MiningCore')); & $refrescarLista
        $lb.SelectedIndex = $lista.Count - 1
    })
    $bDel.Add_Click({
        if ($script:apiSel -lt 0) { return }
        $r = [System.Windows.Forms.MessageBox]::Show(('Quitar "' + $lista[$script:apiSel].nombre + '"?'), 'API de los pools', 'YesNo', 'Question')
        if ($r -ne 'Yes') { return }
        $lista.RemoveAt($script:apiSel); $script:apiSel = -1; & $refrescarLista
        if ($lista.Count -gt 0) { $lb.SelectedIndex = 0 }
    })
    $bDet.Add_Click({
        & $deFormulario
        $n = Api-Detectar $lista $monedasLista $ajustes.suprnova_api_key
        & $refrescarLista
        $lblG.Text = "Anadidos $n pools desde tu configuracion del minero (sin guardar aun)."
        if ($n -gt 0) { $lb.SelectedIndex = $lista.Count - 1 }
    })
    $bProb.Add_Click({
        & $deFormulario
        if ($script:apiSel -lt 0) { $salida.Text = 'Elige un pool de la lista.'; return }
        $salida.Text = 'Consultando...'; $f.Cursor = 'WaitCursor'; [System.Windows.Forms.Application]::DoEvents()
        $r = Api-Consultar $lista[$script:apiSel]
        $f.Cursor = 'Default'
        $salida.Text = ('RESULTADO: ' + (Api-Resumen $r) + "`r`n`r`n" + $r.crudo) -replace "(?<!`r)`n", "`r`n"
    })
    $bGuar.Add_Click({
        & $deFormulario
        try { Api-Guardar $lista; & $refrescarLista; if ($script:apiSel -ge 0) { $lb.SelectedIndex = $script:apiSel }; $lblG.Text = 'Guardado en monitor\pools_api.json (claves cifradas).'; $script:apiCambios = $true }
        catch { $lblG.Text = 'No se pudo guardar: ' + $_.Exception.Message }
    })
    $bCerr.Add_Click({ $f.Close() })

    & $refrescarLista
    if ($lista.Count -gt 0) { $lb.SelectedIndex = 0 }
    else { $salida.Text = 'No hay pools configurados. Pulsa "Detectar" para crearlos desde tus pools del minero, o "Anadir".' + "`r`n" + $salida.Text }
    [void]$f.ShowDialog()
    $f.Dispose()
    return $script:apiCambios
}
