@echo off
REM Panel del minero v5: pestana GPUs (varias GPU, vatios y reloj por tarjeta) y comision declarada del autor.
REM Antes de la primera vez: ejecuta multigpu\compilar_lanzador.bat. Los paneles anteriores siguen en minar.bat ... minar4.bat.
powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0minero_gui5.ps1"
