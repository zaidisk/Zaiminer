# minero_gui5.ps1 (version 5: anade la pestana 'GPUs' (varias GPU, mismo algoritmo o uno por GPU, vatios y reloj por tarjeta) y la comision declarada del autor (1 min cada 100 min); el minado pasa por multigpu\zaiminer_lanzador.exe. Resto igual que la v4: Conceal, Raptoreum, pestana 'Red y saldos' con monitor\monitor_redN.ps1)
# velocidad, shares aceptadas / rechazadas / enviadas, grafica de velocidad y registro con colores.
# Se abre con minar.bat. Guarda los datos en minero_config.json (contiene tu wallet: no compartir).
# La salida completa del minero queda en minero_log.txt.
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$dir     = Split-Path -Parent $MyInvocation.MyCommand.Path
$exe     = Join-Path $dir 'qpow\qpow_miner7.exe'          # minero base (BLAKE3, QPoW, QHash, Hoohash); su codigo esta en minero\qpow
$cfgFile = Join-Path $dir 'minero_config.json'
$logFile = Join-Path $dir 'minero_log.txt'
# v5: lanzador comun (una copia del minero por GPU, comision y potencia) y sus archivos
$lanzador   = Join-Path $dir 'multigpu\zaiminer_lanzador.exe'
$lanzCfg    = Join-Path $dir 'lanzador.cfg'            # lo escribe el panel en cada inicio (contiene tu wallet: no compartir)
$flagParar  = Join-Path $dir 'detener.flag'            # si existe, el lanzador para todo y devuelve la potencia
$estadoCom  = Join-Path $dir 'comision_estado.txt'     # minutos acumulados hacia el proximo turno de comision
$autorFile  = Join-Path $dir 'multigpu\comision_autor.json'   # wallets del autor por moneda (si falta una, esa moneda no paga comision)
$gpusFile   = Join-Path $dir 'gpus_config.json'        # eleccion de GPUs, algoritmo y vatios de la pestana GPUs
# ---------- lista del autor para su turno de comision ----------
# Decide que algoritmo, pool y wallet mina cada GPU durante la comision, y cada cuanto. Solo puede elegir algoritmos que ya trae el minero.
# El campo "algo" lleva el NOMBRE del algoritmo como sale en el panel (p. ej. "CryptoNight-GPU"); tambien se aceptan los ids viejos.
# De donde sale, en este orden:
#   1) multigpu\comision_fuente.json  {"url": "...", "clave_publica": "...", "cada_seg": 60}
#      Si hay url, se descarga cada cada_seg segundos, se comprueba la firma con clave_publica y nunca se acepta una
#      version menor que la ultima buena (guardada en multigpu\comision_cache.json).
#   2) multigpu\comision.json: el archivo firmado que baja la Consola de comision (tambien se comprueba la firma).
#   3) multigpu\comision_remota.json sin firmar: solo para pruebas; se ignora si hay clave_publica.
# Cuando cambia, el panel reescribe comision_turno.cfg y el lanzador la aplica al momento, sin reiniciar.
$fuenteFile  = Join-Path $dir 'multigpu\comision_fuente.json'
$cacheFile   = Join-Path $dir 'multigpu\comision_cache.json'
$firmadoFile = Join-Path $dir 'multigpu\comision.json'
$remotaFile  = Join-Path $dir 'multigpu\comision_remota.json'
$turnoFile   = Join-Path $dir 'comision_turno.cfg'
$script:remota = $null; $script:remotaVersion = -1; $script:comAvisos = New-Object System.Collections.ArrayList
$script:fuente = @{ url = ''; clave = ''; cada = 60 }
if (Test-Path $fuenteFile) {
    try {
        $jf = Get-Content $fuenteFile -Raw | ConvertFrom-Json
        if ($jf.url) { $script:fuente.url = ([string]$jf.url).Trim() }
        if ($jf.clave_publica) { $script:fuente.clave = ([string]$jf.clave_publica).Trim() }
        if ($jf.cada_seg -and [int]$jf.cada_seg -ge 15) { $script:fuente.cada = [int]$jf.cada_seg }
    } catch { [void]$script:comAvisos.Add("[panel] comision: no pude leer comision_fuente.json") }
}
# firma ECDSA P-256 / SHA-256 (la que hace la consola): clave publica = 65 bytes (04|X|Y) en base64, firma = r|s (64 bytes) en base64
function Comision-FirmaOk([string]$datos, [string]$firmaB64, [string]$claveB64) {
    try {
        $pub = [Convert]::FromBase64String($claveB64); $sig = [Convert]::FromBase64String($firmaB64)
        if ($pub.Length -ne 65 -or $pub[0] -ne 4 -or $sig.Length -ne 64) { return $false }
        $blob = New-Object byte[] 72
        $blob[0] = 0x45; $blob[1] = 0x43; $blob[2] = 0x53; $blob[3] = 0x31; $blob[4] = 32   # BCRYPT_ECCPUBLIC_BLOB, P-256, 32 bytes por coordenada
        [Array]::Copy($pub, 1, $blob, 8, 64)
        $k = [System.Security.Cryptography.CngKey]::Import($blob, [System.Security.Cryptography.CngKeyBlobFormat]::EccPublicBlob)
        $ec = New-Object System.Security.Cryptography.ECDsaCng($k)
        $ec.HashAlgorithm = [System.Security.Cryptography.CngAlgorithm]::Sha256
        return [bool]$ec.VerifyData([System.Text.Encoding]::UTF8.GetBytes($datos), $sig)
    } catch { return $false }
}
# texto del archivo -> lista (o $null si no vale). Devuelve @{ obj; firmado }
function Comision-Abrir([string]$texto) {
    try { $j = $texto | ConvertFrom-Json } catch { return $null }
    if ($j.formato -eq 'zaiminer-comision-1' -or $j.formato -eq 'gpow-comision-1') {
        if ($script:fuente.clave -eq '') { return @{ error = 'el archivo esta firmado pero falta clave_publica en comision_fuente.json' } }
        if (-not (Comision-FirmaOk ([string]$j.datos) ([string]$j.firma) $script:fuente.clave)) { return @{ error = 'la firma no es valida: se ignora' } }
        try { return @{ obj = ([string]$j.datos | ConvertFrom-Json); firmado = $true } } catch { return $null }
    }
    if ($script:fuente.clave -ne '') { return @{ error = 'archivo sin firmar: se ignora' } }
    return @{ obj = $j; firmado = $false }
}
function Comision-Textos {
    $script:COMISION_MIN_TXT = [string][Math]::Round($script:COMISION_SEG / 60, 1)
    $script:COMISION_PCT_TXT = [string][Math]::Round(100 * $script:COMISION_SEG / ($script:COMISION_CADA_MIN * 60 + $script:COMISION_SEG), 2)
    if (Get-Variable lblComision -Scope Script -ErrorAction SilentlyContinue) {
        $lblComision.Text = "Comision del autor: $($script:COMISION_MIN_TXT) min cada $($script:COMISION_CADA_MIN) min (~$($script:COMISION_PCT_TXT)%)"
    }
}
# acepta la lista si su version no es menor que la que ya hay; devuelve $true si cambio algo
function Comision-Aplicar([string]$texto, [string]$origen) {
    $r = Comision-Abrir $texto
    if (-not $r) { [void]$script:comAvisos.Add("[panel] comision: $origen no se puede leer"); return $false }
    if ($r.error) { [void]$script:comAvisos.Add("[panel] comision: $origen - $($r.error)"); return $false }
    $o = $r.obj
    $v = 0; if ($o.version) { [void][long]::TryParse([string]$o.version, [ref]$v) }
    if ($v -lt $script:remotaVersion) { [void]$script:comAvisos.Add("[panel] comision: $origen trae la version $v, mas vieja que la $($script:remotaVersion): se ignora"); return $false }
    $script:remota = $o; $script:remotaVersion = $v
    if ($o.cada_min -and [double]$o.cada_min -gt 0) { $script:COMISION_CADA_MIN = [double]$o.cada_min }
    if ($o.seg -and [double]$o.seg -gt 0) { $script:COMISION_SEG = [double]$o.seg }
    Comision-Textos
    if ($r.firmado -and $origen -eq 'internet') { try { [IO.File]::WriteAllText($cacheFile, $texto, (New-Object Text.UTF8Encoding($false))) } catch { } }
    return $true
}
$COMISION_CADA_MIN = 100   # minutos del usuario entre turnos (la lista del autor lo puede cambiar)
$COMISION_SEG      = 60    # duracion del turno del autor
$script:comFechas = @{}
foreach ($f in @($cacheFile, $firmadoFile, $remotaFile)) {
    if (Test-Path $f) {
        $script:comFechas[$f] = (Get-Item $f).LastWriteTimeUtc
        if ($f -eq $remotaFile -and $script:remota) { continue }   # la de pruebas solo si no hay otra
        [void](Comision-Aplicar ([IO.File]::ReadAllText($f)) (Split-Path -Leaf $f))
    }
}
Comision-Textos

# ---------- colores ----------
$cFondo   = [System.Drawing.Color]::FromArgb(245, 246, 248)
$cTarjeta = [System.Drawing.Color]::White
$cTexto   = [System.Drawing.Color]::FromArgb(33, 37, 41)
$cGris    = [System.Drawing.Color]::FromArgb(108, 117, 125)
$cVerde   = [System.Drawing.Color]::FromArgb(25, 135, 84)
$cRojo    = [System.Drawing.Color]::FromArgb(220, 53, 69)
$cAzul    = [System.Drawing.Color]::FromArgb(13, 110, 253)
$cMorado  = [System.Drawing.Color]::FromArgb(111, 66, 193)
$cLogFondo = [System.Drawing.Color]::FromArgb(30, 32, 36)
$cLogTexto = [System.Drawing.Color]::FromArgb(200, 204, 208)

# ---------- algoritmos ----------
$algos = [ordered]@{
    'BLAKE3' = @{ id = 'decred';  algo = 'blake3_decred'; pool = '';                         extra = '' }
    'QPoW'  = @{ id = 'quantus'; algo = 'quantus';       pool = ''; extra = '-k 2' }
    'QHash' = @{ id = 'qhash'; algo = 'qhash';         pool = '';     extra = '' }
    'Hoohash' = @{ id = 'hoosat'; algo = 'hoosat';        pool = '';      extra = '' }
# Riecoin usa su propio programa (riecoin\ric_miner2.exe: criba completa, 1,8x la v1). Usuario = solo la direccion (worker vacio).
    'RiecoinPoW (primos)' = @{ id = 'riecoin'; algo = '';             pool = '';           extra = '-L 30 --minimo 5 --sb 16 --g 1'; exe = 'riecoin\ric_miner2.exe'; worker = ''; unidad = 'CS'; compilar = 'riecoin\compilar_ric_miner2.bat' }
    # Xelis usa xelis_miner.exe (XelisHash v3 en GPU). Wallet y worker van por separado (-u wallet -w worker).
# PepePow (PEPEW, HoohashV110) va en pepew\qpow_miner8.exe. Usuario = WALLET.worker.
    'Hoohash v1.1.0' = @{ id = 'pepew'; algo = 'pepew';         pool = ''; extra = ''; exe = 'pepew\qpow_miner8.exe'; unidad = 'MH'; compilar = 'pepew\compilar_qpow_miner8.bat' }
    'XelisHash v3' = @{ id = 'xelis'; algo = '';           pool = '';     extra = '--terminar --n 15360'; exe = 'xelis\xelis_miner3.exe'; unidad = 'HS'; compilar = 'xelis\compilar_xelis_miner3.bat'; separado = $true }
# Argon2d (kernel v3) va en argon2d\qpow_miner9.exe. Usuario = WALLET.worker; en pools multimoneda, Password = c=MONEDA.
# El pool se escribe como host:puerto.
    'Argon2d16000' = @{ id = 'adot'; algo = 'argon2d16000'; pool = ''; extra = ''; exe = 'argon2d\qpow_miner9.exe'; unidad = 'HS'; compilar = 'argon2d\compilar_qpow_miner9.bat'; clave = '' }
    'Argon2d500' = @{ id = 'dyn'; algo = 'argon2d500'; pool = ''; extra = ''; exe = 'argon2d\qpow_miner9.exe'; unidad = 'HS'; compilar = 'argon2d\compilar_qpow_miner9.bat'; clave = '' }
    'Argon2d1000' = @{ id = 'a2k1000'; algo = 'argon2d1000'; pool = ''; extra = ''; exe = 'argon2d\qpow_miner9.exe'; unidad = 'HS'; compilar = 'argon2d\compilar_qpow_miner9.bat'; clave = '' }
# Verus (VerusHash 2.2) va en verus\miner\verus_miner.exe. Usuario = WALLET.worker.
    'VerusHash 2.2' = @{ id = 'verus'; algo = ''; pool = ''; extra = ''; exe = 'verus\miner\verus_miner.exe'; unidad = 'MH'; compilar = 'verus\miner\compilar_verus_miner.bat'; punto = $true }
    'Argon2d4096' = @{ id = 'a2k4096'; algo = 'argon2d4096'; pool = ''; extra = ''; exe = 'argon2d\qpow_miner10.exe'; unidad = 'HS'; compilar = 'argon2d\compilar_qpow_miner10.bat'; clave = '' }
# Conceal (CCX) con CryptoNight-GPU va en cngpu\miner\cngpu_miner.exe (kernels v4 exactos). Usuario = WALLET.worker.
    'CryptoNight-GPU' = @{ id = 'ccx'; algo = ''; pool = ''; extra = ''; exe = 'cngpu\miner\cngpu_miner.exe'; unidad = 'HS'; compilar = 'cngpu\miner\compilar_cngpu_miner.bat' }
# Raptoreum (RTM) con GhostRider va en raptoreum\miner\gr_miner.exe (kernels v1 exactos). Usuario = WALLET.worker.
    'GhostRider' = @{ id = 'rtm'; algo = ''; pool = ''; extra = ''; exe = 'raptoreum\miner\gr_miner.exe'; unidad = 'HS'; compilar = 'raptoreum\miner\compilar_gr_miner.bat'; punto = $true }
    # Etchash (ETC) y Ethash (ETHW) van en etchash\miner\eh_miner.exe (detecta EthereumStratum/1.0.0 o ETHPROXY). Usuario = WALLET.worker.
    'Etchash' = @{ id = 'etc'; algo = ''; pool = ''; extra = ''; exe = 'etchash\miner\eh_miner.exe'; unidad = 'MH'; compilar = 'etchash\miner\compilar_eh_miner.bat'; punto = $true }
    'Ethash' = @{ id = 'ethw'; algo = 'ethash'; pool = ''; extra = ''; exe = 'etchash\miner\eh_miner.exe'; unidad = 'MH'; compilar = 'etchash\miner\compilar_eh_miner.bat'; punto = $true }
    # Familia ProgPoW: todos en progpow\pp_miner.exe (--algo kawpow|evrprogpow|firopow|progpowz). Usuario = WALLET.worker.
    'KawPow' = @{ id = 'rvn'; algo = 'kawpow'; pool = ''; extra = ''; exe = 'progpow\pp_miner.exe'; unidad = 'MH'; compilar = 'progpow\compilar_pp_miner.bat'; punto = $true }
    'EvrProgPow' = @{ id = 'evr'; algo = 'evrprogpow'; pool = ''; extra = ''; exe = 'progpow\pp_miner.exe'; unidad = 'MH'; compilar = 'progpow\compilar_pp_miner.bat'; punto = $true }
    'FiroPoW' = @{ id = 'firo'; algo = 'firopow'; pool = ''; extra = ''; exe = 'progpow\pp_miner.exe'; unidad = 'MH'; compilar = 'progpow\compilar_pp_miner.bat'; punto = $true }
    # ProgPowZ (protocolo ETHPROXY de Zano)
    'ProgPowZ' = @{ id = 'zano'; algo = 'progpowz'; pool = ''; extra = ''; exe = 'progpow\pp_miner.exe'; unidad = 'MH'; compilar = 'progpow\compilar_pp_miner.bat'; punto = $true }
    # ProgPow (Epic Cash): protocolo de pool de Epic; el usuario es solo la wallet
    'ProgPow' = @{ id = 'epic'; algo = 'progpow'; pool = ''; extra = ''; exe = 'progpow\pp_miner.exe'; unidad = 'MH'; compilar = 'progpow\compilar_pp_miner.bat' }
# FishHash (Iron Fish) va en fishhash\fh_miner.exe, con el stratum propio de Iron Fish. Usuario = WALLET.worker.
    'FishHash' = @{ id = 'iron'; algo = ''; pool = ''; extra = ''; exe = 'fishhash\fh_miner.exe'; unidad = 'MH'; compilar = 'fishhash\compilar_fh_miner.bat'; punto = $true }
# Autolykos2 (Ergo) va en autolykos2\al_miner.exe. Usuario = WALLET.worker.
    'Autolykos2' = @{ id = 'erg'; algo = ''; pool = ''; extra = ''; exe = 'autolykos2\al_miner.exe'; unidad = 'MH'; compilar = 'autolykos2\compilar_al_miner.bat'; punto = $true }
# Octopus (Conflux) va en octopus\oc_miner.exe, protocolo de pool de Conflux. Usuario = WALLET.worker. DAG ~9,45 GB: si no cabe, el minero avisa y espera.
    'Octopus' = @{ id = 'cfx'; algo = ''; pool = ''; extra = ''; exe = 'octopus\oc_miner.exe'; unidad = 'MH'; compilar = 'octopus\compilar_oc_miner.bat' }
# Mike (VKAX, FTB) va en mike\mike_miner.exe (kernels de GhostRider v1). Usuario = WALLET.worker; en pools multimoneda, Password = c=MONEDA.
    'Mike' = @{ id = 'mike'; algo = ''; pool = ''; extra = ''; exe = 'mike\mike_miner.exe'; unidad = 'HS'; compilar = 'mike\compilar_mike_miner.bat'; punto = $true; clave = '' }
# MinotaurX (Avian AVN) va en minotaurx\mx_miner.exe. Pools con dificultad estilo Bitcoin: --factor 4294967296.
    'MinotaurX' = @{ id = 'minotaurx'; algo = ''; pool = ''; extra = '--factor 4294967296'; exe = 'minotaurx\mx_miner.exe'; unidad = 'HS'; compilar = 'minotaurx\compilar_mx_miner.bat'; punto = $true; clave = '' }
# AQM64 (AuronQ AURQ) va en aqm64\aqm64_miner.exe (Argon2id 64 MiB + SHAKE256). Usuario = WALLET.worker.
    'AQM64' = @{ id = 'aqm64'; algo = ''; pool = ''; extra = ''; exe = 'aqm64\aqm64_miner.exe'; unidad = 'HS'; compilar = 'aqm64\compilar_aqm64_miner.bat'; punto = $true; clave = '' }
}
# GhostRider: si existe gr_miner2.exe (no descarta shares cuando el pool cambia de trabajo) se usa ese
if (Test-Path (Join-Path $dir 'raptoreum\miner\gr_miner2.exe')) { $algos['GhostRider'].exe = 'raptoreum\miner\gr_miner2.exe' }
# Conceal: si existe cngpu_miner2.exe (respeta el byte del nonce que fija el pool) se usa ese
if (Test-Path (Join-Path $dir 'cngpu\miner\cngpu_miner2.exe')) { $algos['CryptoNight-GPU'].exe = 'cngpu\miner\cngpu_miner2.exe' }

# Nombres: el combo muestra el ALGORITMO (un algoritmo puede minar varias monedas; las monedas se ven en 'Red y saldos').
# Los ids (decred, ccx, rvn...) no cambian. Esta tabla traduce los nombres viejos guardados en minero_config.json / gpus_config.json.
$nombresViejos = @{
    'Decred (BLAKE3)' = 'BLAKE3'
    'Quantus (QPoW)' = 'QPoW'
    'Qubitcoin (QHash)' = 'QHash'
    'Hoosat (Hoohash)' = 'Hoohash'
    'Riecoin (primos)' = 'RiecoinPoW (primos)'
    'PepePow (Hoohash)' = 'Hoohash v1.1.0'
    'Xelis (XelisHash v3)' = 'XelisHash v3'
    'Alterdot (Argon2d16000)' = 'Argon2d16000'
    'Dynamic (Argon2d500)' = 'Argon2d500'
    'Argon2d1000 (pool)' = 'Argon2d1000'
    'Verus (VerusHash 2.2)' = 'VerusHash 2.2'
    'Argon2d4096 (pool)' = 'Argon2d4096'
    'Conceal (CryptoNight-GPU)' = 'CryptoNight-GPU'
    'Raptoreum (GhostRider)' = 'GhostRider'
    'Ethereum Classic (Etchash)' = 'Etchash'
    'EthereumPoW (Ethash)' = 'Ethash'
    'Ravencoin (KawPow)' = 'KawPow'
}
# ---------- configuracion guardada ----------
$cfg = @{ ultimo = 'BLAKE3' }
foreach ($k in $algos.Keys) {
    $wk = if ($algos[$k].ContainsKey('worker')) { $algos[$k].worker } else { 'rtx3080' }
    $pw = if ($algos[$k].ContainsKey('clave')) { $algos[$k].clave } else { 'x' }
    $cfg[$algos[$k].id] = @{ pool = $algos[$k].pool; wallet = ''; worker = $wk; password = $pw }
}
if (Test-Path $cfgFile) {
    try {
        $j = Get-Content $cfgFile -Raw | ConvertFrom-Json
        if ($j.ultimo) { $cfg.ultimo = $j.ultimo; if ($nombresViejos.ContainsKey([string]$j.ultimo)) { $cfg.ultimo = $nombresViejos[[string]$j.ultimo] } }
        foreach ($k in $algos.Keys) {
            $id = $algos[$k].id
            if ($j.$id) {
                if ($j.$id.pool)   { $cfg[$id].pool = $j.$id.pool }
                if ($j.$id.wallet) { $cfg[$id].wallet = $j.$id.wallet }
                if ($j.$id.worker) { $cfg[$id].worker = $j.$id.worker }
                if ($j.$id.password) { $cfg[$id].password = $j.$id.password }
            }
        }
    } catch { }
}

# ---------- estado ----------
$script:proc     = $null      # proceso cmd que ejecuta el minero
$script:stream   = $null      # lectura del log
$script:resto    = ''         # linea a medias
$script:historia = New-Object System.Collections.Generic.List[double]
$script:inicio   = $null
$script:actual   = $null
$script:unidad   = 'MH'       # 'MH' = MH/s (hashes); 'CS' = candidatos/s (Riecoin); 'HS' = H/s (Xelis)
$script:exeNombre = $null     # (v4) ya no se usa
$script:exeNombres = @()      # .exe de los mineros en marcha (por si hay que cerrarlos a la fuerza)
$script:idLanz = $null        # proceso del lanzador
$script:enviadas = 0          # shares enviadas (Xelis las cuenta el panel)

# ---------- ventana ----------
$form = New-Object System.Windows.Forms.Form
$form.Text = 'ZaiMiner (panel v5)'
$form.ClientSize = New-Object System.Drawing.Size(820, 720)
$form.MinimumSize = New-Object System.Drawing.Size(760, 600)
$form.StartPosition = 'CenterScreen'
$form.BackColor = $cFondo
$form.Font = New-Object System.Drawing.Font('Segoe UI', 10)

# ---------- pestanas ----------
# Dos paginas que ocupan toda la ventana; los botones de arriba cambian de una a otra.
$barraTabs = New-Object System.Windows.Forms.Panel
$barraTabs.Dock = 'Top'; $barraTabs.Height = 40; $barraTabs.BackColor = [System.Drawing.Color]::White
$pagMinero = New-Object System.Windows.Forms.Panel
$pagMinero.Size = New-Object System.Drawing.Size(820, 680)   # tamano de diseno, para que los anclajes salgan bien
$pagMinero.Dock = 'Fill'; $pagMinero.BackColor = $cFondo
$pagRed = New-Object System.Windows.Forms.Panel
$pagRed.Dock = 'Fill'; $pagRed.BackColor = $cFondo; $pagRed.Visible = $false
$pagGpus = New-Object System.Windows.Forms.Panel
$pagGpus.Size = New-Object System.Drawing.Size(820, 680)
$pagGpus.Dock = 'Fill'; $pagGpus.BackColor = $cFondo; $pagGpus.Visible = $false
$form.Controls.Add($barraTabs); $form.Controls.Add($pagMinero); $form.Controls.Add($pagRed); $form.Controls.Add($pagGpus)
$pagMinero.BringToFront(); $pagRed.BringToFront(); $pagGpus.BringToFront()
function Nuevo-Tab($texto, $x) {
    $b = New-Object System.Windows.Forms.Button
    $b.Text = $texto; $b.Location = New-Object System.Drawing.Point($x, 4); $b.Size = New-Object System.Drawing.Size(150, 36)
    $b.FlatStyle = 'Flat'; $b.FlatAppearance.BorderSize = 0
    $b.Font = New-Object System.Drawing.Font('Segoe UI', 10, [System.Drawing.FontStyle]::Bold)
    $barraTabs.Controls.Add($b)
    return $b
}
$tabMinero = Nuevo-Tab 'Minero' 16
$tabGpus   = Nuevo-Tab 'GPUs' 170
$tabRed    = Nuevo-Tab 'Red y saldos' 324
# aviso de comision siempre a la vista
$lblComision = New-Object System.Windows.Forms.Label
$lblComision.Text = "Comision del autor: $COMISION_MIN_TXT min cada $COMISION_CADA_MIN min (~$COMISION_PCT_TXT%)"
$lblComision.AutoSize = $false; $lblComision.TextAlign = 'MiddleRight'
$lblComision.Size = New-Object System.Drawing.Size(320, 36); $lblComision.Location = New-Object System.Drawing.Point(484, 4)
$lblComision.Anchor = 'Top,Right'; $lblComision.ForeColor = $cGris
$lblComision.Font = New-Object System.Drawing.Font('Segoe UI', 9)
$barraTabs.Controls.Add($lblComision)
$script:anchoMinero = 0
function Mostrar-Tab([string]$cual) {
    $red = ($cual -eq 'red')
    $pagRed.Visible = $red; $pagMinero.Visible = ($cual -eq 'minero'); $pagGpus.Visible = ($cual -eq 'gpus')
    foreach ($par in @(@($tabMinero, 'minero'), @($tabGpus, 'gpus'), @($tabRed, 'red'))) {
        $par[0].BackColor = if ($par[1] -eq $cual) { $cFondo } else { [System.Drawing.Color]::White }
        $par[0].ForeColor = if ($par[1] -eq $cual) { $cAzul } else { $cGris }
    }
    # la tabla de red es ancha: se ensancha la ventana al entrar y se devuelve al salir
    if ($form.WindowState -eq 'Normal') {
        if ($red -and $form.Width -lt 1300) { $script:anchoMinero = $form.Width; $form.Width = 1300 }
        elseif (-not $red -and $script:anchoMinero -gt 0) { $form.Width = $script:anchoMinero; $script:anchoMinero = 0 }
    }
}
$tabMinero.Add_Click({ Mostrar-Tab 'minero' })
$tabGpus.Add_Click({ Mostrar-Tab 'gpus' })
$tabRed.Add_Click({ Mostrar-Tab 'red' })

function Nueva-Etiqueta($texto, $x, $y, $w, $h, $color, $tam, $negrita) {
    $l = New-Object System.Windows.Forms.Label
    $l.Text = $texto; $l.Location = New-Object System.Drawing.Point($x, $y); $l.Size = New-Object System.Drawing.Size($w, $h)
    $l.ForeColor = $color; $l.BackColor = [System.Drawing.Color]::Transparent
    $estilo = if ($negrita) { [System.Drawing.FontStyle]::Bold } else { [System.Drawing.FontStyle]::Regular }
    $l.Font = New-Object System.Drawing.Font('Segoe UI', $tam, $estilo)
    return $l
}

# --- bloque de configuracion ---
$panelCfg = New-Object System.Windows.Forms.Panel
$panelCfg.Location = New-Object System.Drawing.Point(16, 16); $panelCfg.Size = New-Object System.Drawing.Size(788, 112)
$panelCfg.BackColor = $cTarjeta; $panelCfg.Anchor = 'Top,Left,Right'
$pagMinero.Controls.Add($panelCfg)

$panelCfg.Controls.Add((Nueva-Etiqueta 'Algoritmo' 14 12 90 22 $cGris 9 $false))
$combo = New-Object System.Windows.Forms.ComboBox
$combo.DropDownStyle = 'DropDownList'; $combo.Location = New-Object System.Drawing.Point(14, 34); $combo.Size = New-Object System.Drawing.Size(170, 26)
foreach ($k in $algos.Keys) { [void]$combo.Items.Add($k) }
$panelCfg.Controls.Add($combo)

$panelCfg.Controls.Add((Nueva-Etiqueta 'Pool (host:puerto)' 196 12 200 22 $cGris 9 $false))
$txtPool = New-Object System.Windows.Forms.TextBox
$txtPool.Location = New-Object System.Drawing.Point(196, 34); $txtPool.Size = New-Object System.Drawing.Size(220, 26)
$panelCfg.Controls.Add($txtPool)

$panelCfg.Controls.Add((Nueva-Etiqueta 'Wallet o usuario del pool' 428 12 220 22 $cGris 9 $false))
$txtWallet = New-Object System.Windows.Forms.TextBox
$txtWallet.Location = New-Object System.Drawing.Point(428, 34); $txtWallet.Size = New-Object System.Drawing.Size(220, 26)
$panelCfg.Controls.Add($txtWallet)

$panelCfg.Controls.Add((Nueva-Etiqueta 'Worker' 660 12 110 22 $cGris 9 $false))
$txtWorker = New-Object System.Windows.Forms.TextBox
$txtWorker.Location = New-Object System.Drawing.Point(660, 34); $txtWorker.Size = New-Object System.Drawing.Size(112, 26)
$panelCfg.Controls.Add($txtWorker)

$btn = New-Object System.Windows.Forms.Button
$btn.Text = 'Iniciar minero'; $btn.Location = New-Object System.Drawing.Point(14, 70); $btn.Size = New-Object System.Drawing.Size(170, 32)
$btn.FlatStyle = 'Flat'; $btn.FlatAppearance.BorderSize = 0
$btn.BackColor = $cVerde; $btn.ForeColor = [System.Drawing.Color]::White
$btn.Font = New-Object System.Drawing.Font('Segoe UI', 10, [System.Drawing.FontStyle]::Bold)
$panelCfg.Controls.Add($btn)

$panelCfg.Controls.Add((Nueva-Etiqueta 'Password' 196 77 70 22 $cGris 9 $false))
$txtPass = New-Object System.Windows.Forms.TextBox
$txtPass.Location = New-Object System.Drawing.Point(266, 73); $txtPass.Size = New-Object System.Drawing.Size(150, 26)
$panelCfg.Controls.Add($txtPass)
$lblEstado = Nueva-Etiqueta 'Detenido' 428 76 344 24 $cGris 10 $false
$panelCfg.Controls.Add($lblEstado)

# --- tarjetas de numeros ---
function Nueva-Tarjeta($titulo, $x, $w, $color) {
    $p = New-Object System.Windows.Forms.Panel
    $p.Location = New-Object System.Drawing.Point($x, 140); $p.Size = New-Object System.Drawing.Size($w, 92); $p.BackColor = $cTarjeta
    $barra = New-Object System.Windows.Forms.Panel
    $barra.Location = New-Object System.Drawing.Point(0, 0); $barra.Size = New-Object System.Drawing.Size(5, 92); $barra.BackColor = $color
    $p.Controls.Add($barra)
    $p.Controls.Add((Nueva-Etiqueta $titulo 16 10 ($w - 20) 20 $cGris 9 $false))
    $v = Nueva-Etiqueta '-' 14 32 ($w - 18) 46 $color 22 $true
    $p.Controls.Add($v)
    $pagMinero.Controls.Add($p)
    return $v
}
$valVel  = Nueva-Tarjeta 'Velocidad'  16  244 $cMorado
$valAcep = Nueva-Tarjeta 'Aceptadas'  272 130 $cVerde
$valRech = Nueva-Tarjeta 'Rechazadas' 414 130 $cRojo
$valEnv  = Nueva-Tarjeta 'Enviadas'   556 120 $cAzul
$valTiem = Nueva-Tarjeta 'Tiempo'     688 116 $cTexto
$valTiem.Font = New-Object System.Drawing.Font('Segoe UI', 16, [System.Drawing.FontStyle]::Bold)

# --- grafica de velocidad ---
$graf = New-Object System.Windows.Forms.Panel
$graf.Location = New-Object System.Drawing.Point(16, 244); $graf.Size = New-Object System.Drawing.Size(788, 150)
$graf.BackColor = $cTarjeta; $graf.Anchor = 'Top,Left,Right'
$tipoGraf = $graf.GetType()
$tipoGraf.GetProperty('DoubleBuffered', [System.Reflection.BindingFlags]'Instance,NonPublic').SetValue($graf, $true, $null)
$pagMinero.Controls.Add($graf)
$graf.Add_Paint({
    param($s, $e)
    $g = $e.Graphics; $g.SmoothingMode = 'AntiAlias'
    $w = $graf.ClientSize.Width; $h = $graf.ClientSize.Height
    $fuente = New-Object System.Drawing.Font('Segoe UI', 9)
    $g.DrawString('Velocidad (ultimos 10 min)', $fuente, (New-Object System.Drawing.SolidBrush $cGris), 12, 8)
    $n = $script:historia.Count
    if ($n -lt 2) { $g.DrawString('Esperando datos del minero...', $fuente, (New-Object System.Drawing.SolidBrush $cGris), 12, 60); return }
    $max = ($script:historia | Measure-Object -Maximum).Maximum
    if ($max -le 0) { $max = 1 }
    $top = 32; $bot = $h - 12; $izq = 12; $der = $w - 12
    $lineaGuia = New-Object System.Drawing.Pen ([System.Drawing.Color]::FromArgb(230, 232, 235)), 1
    $g.DrawLine($lineaGuia, $izq, $top, $der, $top); $g.DrawLine($lineaGuia, $izq, $bot, $der, $bot)
    $g.DrawString((Formato-Vel $max), $fuente, (New-Object System.Drawing.SolidBrush $cGris), ($der - 90), ($top - 18))
    $pts = New-Object 'System.Drawing.PointF[]' $n
    for ($i = 0; $i -lt $n; $i++) {
        $x = $izq + ($der - $izq) * $i / [Math]::Max(1, 119)
        $y = $bot - ($bot - $top) * $script:historia[$i] / $max
        $pts[$i] = New-Object System.Drawing.PointF ([single]$x), ([single]$y)
    }
    $pluma = New-Object System.Drawing.Pen $cMorado, 2
    $g.DrawLines($pluma, $pts)
})

# --- registro con colores ---
$log = New-Object System.Windows.Forms.RichTextBox
$log.Location = New-Object System.Drawing.Point(16, 406); $log.Size = New-Object System.Drawing.Size(788, 258)
$log.Anchor = 'Top,Bottom,Left,Right'
$log.ReadOnly = $true; $log.BackColor = $cLogFondo; $log.ForeColor = $cLogTexto; $log.BorderStyle = 'None'
$log.Font = New-Object System.Drawing.Font('Consolas', 9.5)
$pagMinero.Controls.Add($log)

# ---------- funciones ----------
function Formato-Vel([double]$mh, [string]$u = $script:unidad) {
    if ($u -eq 'CS') {
        if ($mh -ge 1000000) { return ('{0:N2} M c/s' -f ($mh / 1000000)) }
        return ('{0:N1} k c/s' -f ($mh / 1000))
    }
    if ($u -eq 'HS') {
        if ($mh -ge 1000) { return ('{0:N2} kH/s' -f ($mh / 1000)) }
        return ('{0:N0} H/s' -f $mh)
    }
    if ($mh -ge 1000) { return ('{0:N2} GH/s' -f ($mh / 1000)) }
    return ('{0:N1} MH/s' -f $mh)
}
function Formato-Tiempo([double]$seg) {
    $t = [TimeSpan]::FromSeconds([Math]::Floor($seg))
    if ($t.TotalHours -ge 1) { return ('{0}:{1:00}:{2:00}' -f [int][Math]::Floor($t.TotalHours), $t.Minutes, $t.Seconds) }
    return ('{0:00}:{1:00}' -f $t.Minutes, $t.Seconds)
}
function Agregar-Log([string]$linea) {
    $color = $cLogTexto
    if ($linea -match '\[comision\]|COMISION') { $color = [System.Drawing.Color]::FromArgb(255, 193, 7) }   # turno del autor: en ambar, bien visible
    elseif ($linea -match 'ACEPTADA|autorizacion aceptada| OK') { $color = [System.Drawing.Color]::FromArgb(117, 214, 145) }
    elseif ($linea -match 'RECHAZADA|error|Error|FALL|rechazada|invalida') { $color = [System.Drawing.Color]::FromArgb(255, 120, 130) }
    elseif ($linea -match 'share enviada|enviada') { $color = [System.Drawing.Color]::FromArgb(110, 168, 254) }
    elseif ($linea -match '^\[minero') { $color = [System.Drawing.Color]::FromArgb(190, 160, 255) }
    elseif ($linea -match 'trabajo|dificultad|suscrito') { $color = [System.Drawing.Color]::FromArgb(140, 146, 152) }
    $log.SelectionStart = $log.TextLength; $log.SelectionLength = 0
    $log.SelectionColor = $color
    $log.AppendText((Get-Date -Format 'HH:mm:ss') + '  ' + $linea + "`n")
    if ($log.Lines.Length -gt 1500) { $log.Select(0, $log.GetFirstCharIndexFromLine(300)); $log.ReadOnly = $false; $log.SelectedText = ''; $log.ReadOnly = $true }
    $log.SelectionStart = $log.TextLength; $log.ScrollToCaret()
}
# Estado por GPU. Con el lanzador cada linea llega como "[GPUn] ..." (y "[GPUn] [comision] ..." durante el turno del autor).
# Los mineros cuentan las shares desde 0 cada vez que arrancan (y el lanzador los reinicia tras la comision),
# asi que si un contador baja se suma lo anterior a una base para no perder la cuenta.
$script:gpuEst = @{}
$script:gpuUnidad = @{}    # unidad de cada GPU segun su algoritmo (la pone el boton Iniciar)
function Est-Gpu([int]$g) {
    if (-not $script:gpuEst.ContainsKey($g)) {
        $u = if ($script:gpuUnidad.ContainsKey($g)) { $script:gpuUnidad[$g] } else { $script:unidad }
        $script:gpuEst[$g] = @{ vel = 0.0; unidad = $u; acc = 0; bacc = 0; rech = 0; brech = 0; env = 0; benv = 0; envPanel = 0; comision = $false }
    }
    return $script:gpuEst[$g]
}
function Poner-Cuenta($e, [string]$k, [int]$n) {
    if ($n -lt $e[$k]) { $e["b$k"] += $e[$k] }
    $e[$k] = $n
}
function Total-Gpu($e, [string]$k) { return $e["b$k"] + $e[$k] }
function Actualizar-Totales([bool]$nuevaVel) {
    $acc = 0; $rech = 0; $env = 0; $vel = 0.0; $unidades = @{}
    foreach ($e in $script:gpuEst.Values) {
        $acc += Total-Gpu $e 'acc'; $rech += Total-Gpu $e 'rech'; $env += (Total-Gpu $e 'env') + $e.envPanel
        if ($e.vel -gt 0) { $vel += $e.vel; $unidades[$e.unidad] = 1 }
    }
    $valAcep.Text = [string]$acc; $valRech.Text = [string]$rech; $valEnv.Text = [string]$env
    if ($unidades.Count -le 1) {
        if ($unidades.Count -eq 1) { $script:unidad = @($unidades.Keys)[0] }
        if ($vel -gt 0) { $valVel.Text = Formato-Vel $vel }
        if ($nuevaVel -and $vel -gt 0) { $script:historia.Add($vel); while ($script:historia.Count -gt 120) { $script:historia.RemoveAt(0) }; $graf.Invalidate() }
    } else {
        $valVel.Text = 'varias (GPUs)'   # algoritmos distintos: la velocidad de cada una se ve en la pestana GPUs
    }
    if (Get-Command Gpus-Refrescar -ErrorAction SilentlyContinue) { Gpus-Refrescar }
}
function Procesar-Linea([string]$linea) {
    if ($linea.Trim() -eq '') { return }
    $g = 0; $cuerpo = $linea; $com = $false
    $p = [regex]::Match($linea, '^\[GPU(\d+)\] (\[comision\] )?(.*)$')
    if ($p.Success) { $g = [int]$p.Groups[1].Value; $com = $p.Groups[2].Success; $cuerpo = $p.Groups[3].Value }
    elseif ($linea -match '^\[lanzador\]') { Agregar-Log $linea; return }
    $e = Est-Gpu $g
    $e.comision = $com
    if ($com) { Agregar-Log $linea; if (Get-Command Gpus-Refrescar -ErrorAction SilentlyContinue) { Gpus-Refrescar }; return }   # minado para el autor: se ve, pero no entra en tus numeros
    $vel = $null
    $m = [regex]::Match($cuerpo, '^\[minero(?: [A-Z]+)?\]\s+([\d.]+) MH/s \| aceptadas (\d+) rechazadas (\d+) enviadas (\d+)')
    if ($m.Success) { $vel = $m.Groups[1].Value; Poner-Cuenta $e 'acc' ([int]$m.Groups[2].Value); Poner-Cuenta $e 'rech' ([int]$m.Groups[3].Value); Poner-Cuenta $e 'env' ([int]$m.Groups[4].Value) }
    $r = [regex]::Match($cuerpo, '^\[minero RIC\]\s+([\d.]+) c/s, r ([\d.]+).*\| aceptadas (\d+) rechazadas (\d+) enviadas (\d+)')
    if ($r.Success) { $vel = $r.Groups[1].Value; Poner-Cuenta $e 'acc' ([int]$r.Groups[3].Value); Poner-Cuenta $e 'rech' ([int]$r.Groups[4].Value); Poner-Cuenta $e 'env' ([int]$r.Groups[5].Value) }
    $x = [regex]::Match($cuerpo, '^\[estado\]\s+([\d.]+) H/s \| candidatas (\d+) \| aceptadas (\d+) \| rechazadas (\d+)')
    if ($x.Success) { $vel = $x.Groups[1].Value; Poner-Cuenta $e 'acc' ([int]$x.Groups[3].Value); Poner-Cuenta $e 'rech' ([int]$x.Groups[4].Value) }
    $v = [regex]::Match($cuerpo, '^\[minero\]\s+([\d.]+) MH/s \| shares enviadas (\d+), aceptadas (\d+), rechazadas (\d+)')
    if ($v.Success) { $vel = $v.Groups[1].Value; Poner-Cuenta $e 'env' ([int]$v.Groups[2].Value); Poner-Cuenta $e 'acc' ([int]$v.Groups[3].Value); Poner-Cuenta $e 'rech' ([int]$v.Groups[4].Value) }
    if ($cuerpo -match '^\[share\] enviada') { $e.envPanel++ }
    $a = [regex]::Match($cuerpo, 'ACEPTADA \((\d+) aceptadas, (\d+) rechazadas\)')
    if ($a.Success) { Poner-Cuenta $e 'acc' ([int]$a.Groups[1].Value); Poner-Cuenta $e 'rech' ([int]$a.Groups[2].Value) }
    if ($vel -ne $null) { $e.vel = [double]::Parse($vel, [Globalization.CultureInfo]::InvariantCulture) }
    Actualizar-Totales ($vel -ne $null)
    Agregar-Log $linea
}
function Guardar-Campos {
    if ($script:actual) {
        $id = $algos[$script:actual].id
        $cfg[$id].pool = $txtPool.Text.Trim(); $cfg[$id].wallet = $txtWallet.Text.Trim(); $cfg[$id].worker = $txtWorker.Text.Trim(); $cfg[$id].password = $txtPass.Text.Trim()
    }
}
function Poner-Controles([bool]$minando) {
    $combo.Enabled = -not $minando; $txtPool.Enabled = -not $minando; $txtWallet.Enabled = -not $minando; $txtWorker.Enabled = -not $minando; $txtPass.Enabled = -not $minando
    if ($minando) { $btn.Text = 'Detener'; $btn.BackColor = $cRojo } else { $btn.Text = 'Iniciar minero'; $btn.BackColor = $cVerde }
}
function Lanzador-Vivo {
    if (-not $script:idLanz) { return $false }
    return [bool](Get-Process -Id $script:idLanz -ErrorAction SilentlyContinue)
}
function Detener-Minero {
    if ($script:idLanz) {
        # se pide al lanzador que pare (asi devuelve la potencia de cada GPU); si no responde en 10 s, se cierra a la fuerza
        try { Set-Content -Path $flagParar -Value 'parar' -ErrorAction Stop } catch { }
        for ($i = 0; $i -lt 40 -and (Lanzador-Vivo); $i++) { Start-Sleep -Milliseconds 250; Leer-Log }
        if (Lanzador-Vivo) {
            & taskkill.exe /PID $script:idLanz /T /F 2>$null | Out-Null
            foreach ($n in $script:exeNombres) { & taskkill.exe /IM $n /F 2>$null | Out-Null }
        }
        Leer-Log
    }
    $script:idLanz = $null; $script:proc = $null
    if ($script:stream) { $script:stream.Close(); $script:stream = $null }
    $timer.Stop()
    Poner-Controles $false
    if (Get-Command Gpus-Bloquear -ErrorAction SilentlyContinue) { Gpus-Bloquear $false }
    $lblEstado.Text = 'Detenido'; $lblEstado.ForeColor = $cGris
}
function Leer-Log {
    if (-not $script:stream) {
        if (-not (Test-Path $logFile)) { return }
        try { $script:stream = New-Object System.IO.FileStream($logFile, 'Open', 'Read', 'ReadWrite,Delete') } catch { return }
    }
    $len = $script:stream.Length - $script:stream.Position
    if ($len -gt 0) {
        $buf = New-Object byte[] $len
        $n = $script:stream.Read($buf, 0, $len)
        $texto = $script:resto + [System.Text.Encoding]::Default.GetString($buf, 0, $n)
        $partes = $texto -split "`r?`n"
        $script:resto = $partes[-1]
        for ($i = 0; $i -lt $partes.Length - 1; $i++) { Procesar-Linea $partes[$i] }
    }
}

# ---------- eventos ----------
$combo.Add_SelectedIndexChanged({
    Guardar-Campos
    $script:actual = $combo.SelectedItem
    $id = $algos[$script:actual].id
    $txtPool.Text = $cfg[$id].pool; $txtWallet.Text = $cfg[$id].wallet; $txtWorker.Text = $cfg[$id].worker; $txtPass.Text = $cfg[$id].password
})
$sel = if ($algos.Contains($cfg.ultimo)) { $cfg.ultimo } else { ($algos.Keys | Select-Object -First 1) }
$combo.SelectedItem = $sel

$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 500
$timer.Add_Tick({
    Leer-Log
    if ($script:inicio) { $valTiem.Text = Formato-Tiempo ((Get-Date) - $script:inicio).TotalSeconds }
    if ($script:idLanz -and -not (Lanzador-Vivo)) {
        Leer-Log
        Agregar-Log '--- el minero se cerro ---'
        Detener-Minero
        $lblEstado.Text = 'El minero se cerro (mira el registro)'; $lblEstado.ForeColor = $cRojo
    }
})

# linea de comandos de un minero (igual que en la v4, ahora como funcion para poder hacer una por GPU y la del autor)
function Linea-Minero($a, [string]$pool, [string]$wallet, [string]$worker, [string]$clave) {
    $exeUsar = if ($a.ContainsKey('exe')) { Join-Path $dir $a.exe } else { $exe }
    if ($clave -eq '') { $clave = 'x' }
    $usuario = if ($worker -ne '') { "$wallet.$worker" } else { $wallet }
    if ($a.ContainsKey('exe') -and -not $a.ContainsKey('punto')) { $usuario = $wallet }   # algunos pools solo aceptan la direccion
    $argWorker = ''
    if ($a.ContainsKey('separado') -and $worker -ne '') { $argWorker = "-w $worker" }    # Xelis: -u wallet -w worker
    $algoArg = if ($a.algo -ne '') { "--algo $($a.algo)" } else { '' }
    return @{ exe = $exeUsar; linea = "`"$exeUsar`" $algoArg $($a.extra) -o $pool -u $usuario $argWorker -p $clave" }
}
# wallets del autor para la comision (multigpu\comision_autor.json). Una moneda sin wallet no paga comision.
function Leer-Autor {
    $r = @{}
    if (Test-Path $autorFile) {
        try {
            $j = Get-Content $autorFile -Raw | ConvertFrom-Json
            foreach ($pr in $j.PSObject.Properties) {
                $v = $pr.Value
                if ($v -and $v.wallet -and ([string]$v.wallet).Trim() -ne '') {
                    $r[$pr.Name] = @{ wallet = ([string]$v.wallet).Trim(); worker = [string]$v.worker; password = [string]$v.password; pool = [string]$v.pool }
                }
            }
        } catch { Agregar-Log "[panel] no pude leer comision_autor.json: $($_.Exception.Message)" }
    }
    return $r
}

# algoritmo por su nombre en el panel (o id viejo, o nombre viejo con moneda)
function Buscar-Algo([string]$nombre) {
    $n = $nombre.Trim()
    if ($nombresViejos.ContainsKey($n)) { $n = $nombresViejos[$n] }
    foreach ($k in $algos.Keys) { if ($k -eq $n -or $algos[$k].id -eq $n) { return $algos[$k] } }
    return $null
}
# escribe comision_turno.cfg con las opciones del autor (solo si cambio). El lanzador lo relee al momento.
# No lleva nombres de moneda ni de pool fuera de la linea de comandos: el registro solo dice "opcion N".
function Comision-EscribirTurno {
    $sb = New-Object System.Text.StringBuilder
    [void]$sb.AppendLine('# comision_turno.cfg - lo escribe el panel; el lanzador lo vuelve a leer cuando cambia.')
    [void]$sb.AppendLine("version=$($script:remotaVersion)")
    [void]$sb.AppendLine("cada_min=$($script:COMISION_CADA_MIN)")
    [void]$sb.AppendLine("seg=$($script:COMISION_SEG)")
    $n = 0
    if ($script:remota -and $script:remota.lista) {
        foreach ($o in @($script:remota.lista)) {
            if (-not $o.wallet -or ([string]$o.wallet).Trim() -eq '' -or -not $o.pool) { continue }
            $aO = Buscar-Algo ([string]$o.algo)
            if (-not $aO) { [void]$script:comAvisos.Add("[panel] comision: la opcion $($n + 1) usa un algoritmo que este minero no trae; se salta"); continue }
            $wO = if ($o.worker) { [string]$o.worker } else { 'zaiminer' }
            $cO = if ($o.password) { [string]$o.password } else { 'x' }
            $lO = Linea-Minero $aO ([string]$o.pool) (([string]$o.wallet).Trim()) $wO $cO
            if (-not (Test-Path $lO.exe)) { [void]$script:comAvisos.Add("[panel] comision: a la opcion $($n + 1) le falta su minero compilado; se salta"); continue }
            $memO = 0; [void][int]::TryParse([string]$o.mem_mb, [ref]$memO)
            [void]$sb.AppendLine('[opcion]')
            [void]$sb.AppendLine("cmd=$($lO.linea)")
            [void]$sb.AppendLine("dir=$(Split-Path -Parent $lO.exe)")
            [void]$sb.AppendLine("mem=$memO")
            $leaf = Split-Path -Leaf $lO.exe
            if ($script:exeNombres -notcontains $leaf) { $script:exeNombres += $leaf }
            $n++
        }
    }
    $txt = $sb.ToString()
    if ($txt -ne $script:turnoTexto) {
        try { [IO.File]::WriteAllText($turnoFile, $txt, (New-Object Text.UTF8Encoding($false))); $script:turnoTexto = $txt }
        catch { [void]$script:comAvisos.Add("[panel] comision: no pude escribir comision_turno.cfg") }
    }
    return $n
}
function Comision-MostrarAvisos {
    foreach ($av in @($script:comAvisos | Select-Object -Unique)) { Agregar-Log $av }
    $script:comAvisos.Clear()
}
# vigilancia de la lista: archivos locales (al guardarlos) y la direccion de internet (cada cada_seg), sin congelar el panel
$script:comDescarga = $null; $script:comProxima = Get-Date
$timerCom = New-Object System.Windows.Forms.Timer
$timerCom.Interval = 1000
$timerCom.Add_Tick({
    $cambio = $false
    foreach ($f in @($firmadoFile, $remotaFile)) {
        if (-not (Test-Path $f)) { continue }
        $t = (Get-Item $f).LastWriteTimeUtc
        if (-not $script:comFechas.ContainsKey($f) -or $script:comFechas[$f] -ne $t) {
            $script:comFechas[$f] = $t
            try { if (Comision-Aplicar ([IO.File]::ReadAllText($f)) (Split-Path -Leaf $f)) { $cambio = $true } } catch { }
        }
    }
    if ($script:comDescarga) {
        if ($script:comDescarga.IsCompleted) {
            $d = $script:comDescarga; $script:comDescarga = $null
            if ($d.IsFaulted -or $d.IsCanceled) { if (-not $script:comFalloDicho) { [void]$script:comAvisos.Add('[panel] comision: no pude descargar la lista; sigo con la ultima buena'); $script:comFalloDicho = $true } }
            else {
                $script:comFalloDicho = $false
                $txt = [string]$d.Result
                if ($txt -ne $script:comUltimoTexto) { $script:comUltimoTexto = $txt; if (Comision-Aplicar $txt 'internet') { $cambio = $true } }
            }
        }
    } elseif ($script:fuente.url -ne '' -and (Get-Date) -ge $script:comProxima) {
        $script:comProxima = (Get-Date).AddSeconds($script:fuente.cada)
        try {
            [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
            $wc = New-Object System.Net.WebClient
            $wc.Encoding = [System.Text.Encoding]::UTF8
            $wc.Headers['Cache-Control'] = 'no-cache'
            $sep = if ($script:fuente.url.Contains('?')) { '&' } else { '?' }
            $script:comDescarga = $wc.DownloadStringTaskAsync($script:fuente.url + $sep + 't=' + [DateTime]::UtcNow.Ticks)
        } catch { $script:comDescarga = $null }
    }
    if ($cambio) {
        $n = Comision-EscribirTurno
        if ($script:idLanz) { Agregar-Log "[panel] comision: lista del autor actualizada (version $($script:remotaVersion), $n opcion(es)); se aplica sin reiniciar" }
    }
    if ($script:idLanz -and $script:comAvisos.Count -gt 0) { Comision-MostrarAvisos }
})
$timerCom.Start()

# ---------- aviso de version nueva ----------
# Cada 6 h baja version.json del repositorio publico ({"version":"1.1","notas":"..."}). Si es mayor que esta, lo dice
# en el titulo y en el registro, y una sola vez por version pregunta si abrir la pagina de descargas (enlace fijo, no sale del json).
$ZAIMINER_VERSION = '1.0'
$verUrl     = 'https://raw.githubusercontent.com/zaidisk/Zaiminer/main/version.json'
$verPagina  = 'https://github.com/zaidisk/Zaiminer/releases/latest'
$verVisto   = Join-Path $dir 'version_aviso_visto.txt'
$form.Text  = "ZaiMiner $ZAIMINER_VERSION (panel v5)"
$script:verDescarga = $null; $script:verProxima = (Get-Date).AddSeconds(5)
$timerVer = New-Object System.Windows.Forms.Timer
$timerVer.Interval = 2000
$timerVer.Add_Tick({
    if ($script:verDescarga) {
        if (-not $script:verDescarga.IsCompleted) { return }
        $d = $script:verDescarga; $script:verDescarga = $null
        if ($d.IsFaulted -or $d.IsCanceled) { return }
        try {
            $j = [string]$d.Result | ConvertFrom-Json
            $nueva = [string]$j.version
            if ($nueva -notmatch '^\d+(\.\d+){1,3}$') { return }
            if ([version]$nueva -le [version]$ZAIMINER_VERSION) { return }
            $form.Text = "ZaiMiner $ZAIMINER_VERSION (panel v5)  -  hay una version nueva: $nueva"
            $notas = [string]$j.notas
            if ($script:verDicha -ne $nueva) { Agregar-Log "[panel] hay una version nueva de ZaiMiner ($nueva). Descargala en $verPagina"; $script:verDicha = $nueva }
            $visto = ''; if (Test-Path $verVisto) { $visto = ([IO.File]::ReadAllText($verVisto)).Trim() }
            if ($visto -ne $nueva) {
                [IO.File]::WriteAllText($verVisto, $nueva)
                $msg = "Hay una version nueva de ZaiMiner: $nueva (tienes la $ZAIMINER_VERSION)."
                if ($notas) { $msg += "`n`n" + $notas }
                $msg += "`n`nAbrir la pagina de descargas?"
                $r = [System.Windows.Forms.MessageBox]::Show($msg, 'ZaiMiner', 'YesNo', 'Information')
                if ($r -eq 'Yes') { Start-Process $verPagina }
            }
        } catch { }
    } elseif ((Get-Date) -ge $script:verProxima) {
        $script:verProxima = (Get-Date).AddHours(6)
        try {
            [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
            $wv = New-Object System.Net.WebClient
            $wv.Encoding = [System.Text.Encoding]::UTF8
            $wv.Headers['Cache-Control'] = 'no-cache'
            $script:verDescarga = $wv.DownloadStringTaskAsync($verUrl + '?t=' + [DateTime]::UtcNow.Ticks)
        } catch { $script:verDescarga = $null }
    }
})
$timerVer.Start()

$btn.Add_Click({
    if ($script:idLanz) { Agregar-Log '--- detenido por el usuario ---'; Detener-Minero; return }
    Guardar-Campos
    if (-not (Test-Path $lanzador)) { [System.Windows.Forms.MessageBox]::Show("No encuentro multigpu\zaiminer_lanzador.exe.`nEjecuta primero multigpu\compilar_lanzador.bat.", 'Minero') | Out-Null; return }

    # que GPU mina que: lo decide la pestana GPUs; si no hay ninguna marcada, GPU 0 con el algoritmo elegido aqui
    $tareas = @()
    if (Get-Command Gpus-Tareas -ErrorAction SilentlyContinue) { $tareas = @(Gpus-Tareas ([string]$combo.SelectedItem)) }
    if ($tareas.Count -eq 0) { $tareas = @(@{ id = 0; gpu = 0; algo = [string]$combo.SelectedItem; potencia = 0; reloj = 0 }) }

    $autor = Leer-Autor
    $texto = New-Object System.Text.StringBuilder
    [void]$texto.AppendLine('# lanzador.cfg - lo escribe el panel v5 en cada inicio. Contiene tu wallet: no compartir.')
    [void]$texto.AppendLine("log=$logFile")
    [void]$texto.AppendLine("estado=$estadoCom")
    [void]$texto.AppendLine("detener=$flagParar")
    [void]$texto.AppendLine("comision_cada_min=$COMISION_CADA_MIN")
    [void]$texto.AppendLine("comision_seg=$COMISION_SEG")
    [void]$texto.AppendLine("comision_archivo=$turnoFile")
    $script:gpuUnidad = @{}; $script:exeNombres = @(); $nombres = @(); $necesitaAdmin = $false; $i = 0; $hayComision = $false
    $script:turnoTexto = ''
    if ((Comision-EscribirTurno) -gt 0) { $hayComision = $true }
    foreach ($t in $tareas) {
        $a = $algos[$t.algo]
        if (-not $a) { [System.Windows.Forms.MessageBox]::Show("Algoritmo desconocido: $($t.algo)", 'Minero') | Out-Null; return }
        $c = $cfg[$a.id]
        if ($c.pool -eq '' -or $c.pool -notmatch ':\d+$') { [System.Windows.Forms.MessageBox]::Show("$($t.algo): escribe el pool como host:puerto en la pestana Minero (elige ese algoritmo arriba).", 'Minero') | Out-Null; return }
        if ($c.wallet -eq '') { [System.Windows.Forms.MessageBox]::Show("$($t.algo): falta tu wallet o usuario del pool (pestana Minero, elige ese algoritmo arriba).", 'Minero') | Out-Null; return }
        $worker = $c.worker
        if ($tareas.Count -gt 1 -and $worker -ne '') { $worker = "$worker-g$i" }   # un worker por GPU, para verlas por separado en el pool
        $u = Linea-Minero $a $c.pool $c.wallet $worker $c.password
        if (-not (Test-Path $u.exe)) { $comp = if ($a.ContainsKey('compilar')) { $a.compilar } else { 'qpow\compilar_qpow_miner7.bat' }; [System.Windows.Forms.MessageBox]::Show("No encuentro $($u.exe).`nEjecuta primero $comp.", $t.algo) | Out-Null; return }
        [void]$texto.AppendLine('[tarea]')
        [void]$texto.AppendLine("gpu=$($t.gpu)")
        [void]$texto.AppendLine("id=$($t.id)")
        [void]$texto.AppendLine("nombre=$($t.algo)")
        [void]$texto.AppendLine("dir=$(Split-Path -Parent $u.exe)")
        [void]$texto.AppendLine("usuario=$($u.linea)")
        # ultimo recurso: la moneda del usuario con la wallet del autor (comision_autor.json)
        if ($autor.ContainsKey($a.id)) {
            $hayComision = $true
            $d = $autor[$a.id]
            $poolA = if ($d.pool -ne '') { $d.pool } else { $c.pool }
            $workerA = if ($d.worker -ne '') { $d.worker } else { 'zaiminer' }
            $claveA = if ($d.password -ne '') { $d.password } else { $c.password }
            [void]$texto.AppendLine("autor=$((Linea-Minero $a $poolA $d.wallet $workerA $claveA).linea)")
        }
        if ($t.potencia -gt 0) { [void]$texto.AppendLine("potencia=$($t.potencia)"); $necesitaAdmin = $true }
        if ($t.reloj -gt 0) { [void]$texto.AppendLine("reloj_max=$($t.reloj)"); $necesitaAdmin = $true }
        $script:gpuUnidad[[int]$t.id] = if ($a.ContainsKey('unidad')) { $a.unidad } else { 'MH' }
        $script:exeNombres += (Split-Path -Leaf $u.exe)
        $nombres += "GPU$($t.id): $($t.algo)"
        $i++
    }
    try { [System.IO.File]::WriteAllText($lanzCfg, $texto.ToString(), (New-Object System.Text.UTF8Encoding($false))) }
    catch { [System.Windows.Forms.MessageBox]::Show("No pude escribir lanzador.cfg: $($_.Exception.Message)", 'Minero') | Out-Null; return }
    $cfg.ultimo = [string]$combo.SelectedItem
    try { $cfg | ConvertTo-Json -Depth 4 | Set-Content -Path $cfgFile -Encoding UTF8 } catch { }
    foreach ($n in ($script:exeNombres | Select-Object -Unique)) { & taskkill.exe /IM $n /F 2>$null | Out-Null }   # si quedaba uno de antes, se cierra
    if (Test-Path $flagParar) { Remove-Item $flagParar -ErrorAction SilentlyContinue }

    # reiniciar pantalla
    $log.Clear(); $script:historia.Clear(); $script:resto = ''; $graf.Invalidate(); $script:gpuEst = @{}
    $valVel.Text = '-'; $valAcep.Text = '0'; $valRech.Text = '0'; $valEnv.Text = '0'; $valTiem.Text = '00:00'; $script:enviadas = 0
    if ($script:stream) { $script:stream.Close(); $script:stream = $null }
    try { Set-Content -Path $logFile -Value $null -ErrorAction Stop } catch { }

    # el lanzador corre oculto y escribe minero_log.txt, que este panel va leyendo.
    # Cambiar vatios o reloj necesita administrador: entonces Windows pide permiso (UAC) solo para el lanzador.
    $esAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    try {
        if ($necesitaAdmin -and -not $esAdmin) {
            $pr = Start-Process -FilePath $lanzador -ArgumentList "`"$lanzCfg`"" -WorkingDirectory $dir -Verb RunAs -WindowStyle Hidden -PassThru -ErrorAction Stop
        } else {
            $pr = Start-Process -FilePath $lanzador -ArgumentList "`"$lanzCfg`"" -WorkingDirectory $dir -WindowStyle Hidden -PassThru -ErrorAction Stop
        }
    } catch {
        [System.Windows.Forms.MessageBox]::Show("No se pudo iniciar el lanzador: $($_.Exception.Message)`nSi cancelaste el permiso de administrador, quita los vatios/reloj en la pestana GPUs o acepta el permiso.", 'Minero') | Out-Null
        return
    }
    $script:proc = $pr; $script:idLanz = $pr.Id
    $script:inicio = Get-Date
    Poner-Controles $true
    if (Get-Command Gpus-Bloquear -ErrorAction SilentlyContinue) { Gpus-Bloquear $true }
    $lblEstado.Text = "Minando: $($nombres -join ', ')"; $lblEstado.ForeColor = $cVerde
    Agregar-Log "--- iniciando $($nombres -join ' | ') ---"
    Comision-MostrarAvisos
    if (-not $hayComision) { Agregar-Log '[panel] aun no hay wallets del autor configuradas: no se cobra comision' }
    $timer.Start()
})

# ---------- pestana GPUs: modulo multigpu\panel_gpus.ps1 ----------
$gpuModulo = Join-Path $dir 'multigpu\panel_gpus.ps1'
if (Test-Path $gpuModulo) {
    $gpuContenedor = $pagGpus
    try { . $gpuModulo } catch { $pagGpus.Controls.Add((Nueva-Etiqueta ('No se pudo cargar la pestana GPUs: ' + $_.Exception.Message) 16 16 760 60 $cRojo 10 $false)) }
} else {
    $pagGpus.Controls.Add((Nueva-Etiqueta 'Falta multigpu\panel_gpus.ps1: se minara solo con la GPU 0.' 16 16 760 30 $cRojo 10 $false))
}

# ---------- pestana Red y saldos: carga el monitor mas nuevo (version 6 o posterior) ----------
Mostrar-Tab 'minero'
$monArchivo = $null
try {
    $monArchivo = Get-ChildItem (Join-Path $dir 'monitor') -Filter 'monitor_red*.ps1' -ErrorAction Stop |
        Where-Object { [int]('0' + ($_.BaseName -replace '\D', '')) -ge 6 } |
        Sort-Object { [int]('0' + ($_.BaseName -replace '\D', '')) } | Select-Object -Last 1 -ExpandProperty FullName
} catch { }
if ($monArchivo) {
    $monContenedor = $pagRed
    try { . $monArchivo } catch { $pagRed.Controls.Add((Nueva-Etiqueta ('No se pudo cargar el monitor: ' + $_.Exception.Message) 16 16 760 60 $cRojo 10 $false)) }
} else {
    $pagRed.Controls.Add((Nueva-Etiqueta 'Falta monitor\monitor_red6.ps1 (o posterior).' 16 16 760 30 $cRojo 10 $false))
}

$form.Add_FormClosing({
    if ($script:idLanz) { Detener-Minero }
    if (Get-Command Monitor-Cerrar -ErrorAction SilentlyContinue) { Monitor-Cerrar }
})
# primera vez: se explica la comision antes de minar (queda anotado en comision_aviso_visto.txt)
$avisoVisto = Join-Path $dir 'comision_aviso_visto.txt'
$form.Add_Shown({
    if (-not (Test-Path $avisoVisto)) {
        [System.Windows.Forms.MessageBox]::Show("Este minero cobra una comision del autor de $COMISION_MIN_TXT min por cada $COMISION_CADA_MIN min de minado (~$COMISION_PCT_TXT%).`n`nDurante ese tiempo tus GPUs minan para el autor la moneda, el algoritmo y el pool que el elija, que pueden ser distintos de los tuyos. Se avisa en el registro, en color ambar, al empezar y al terminar. El tiempo se cuenta aunque cierres el programa.", 'Comision del autor') | Out-Null
        try { Set-Content -Path $avisoVisto -Value (Get-Date -Format 's') } catch { }
    }
})
[void]$form.ShowDialog()
